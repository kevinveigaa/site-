import React from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  /** Se true, redireciona para /login quando não autenticado */
  requireAuth?: boolean;
  /** Se true, redireciona para /assinatura quando sem assinatura ativa */
  requireSubscription?: boolean;
  /** Se true, permite acesso apenas a usuários admin */
  requireAdmin?: boolean;
}

/**
 * Componente de proteção de rotas.
 * Centraliza toda a lógica de acesso para facilitar
 * futura integração com backend/JWT.
 */
export function ProtectedRoute({
  children,
  requireAuth = true,
  requireSubscription = false,
  requireAdmin = false,
}: ProtectedRouteProps) {
  const { user, currentProfile } = useAuth();
  const [, setLocation] = useLocation();

  // Verificar autenticação
  if (requireAuth && !currentProfile) {
    setLocation('/login');
    return null;
  }

  // Verificar assinatura
  if (requireSubscription && user && !user.assinaturaAtiva) {
    setLocation('/assinatura');
    return null;
  }

  // Verificar admin (placeholder para futura integração)
  if (requireAdmin && user?.email !== 'admin@movieflix.com') {
    setLocation('/');
    return null;
  }

  return <>{children}</>;
}
