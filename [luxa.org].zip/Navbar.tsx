import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { Search, Menu, Bell, Palette, UserCircle, LogOut, Settings } from 'lucide-react';

export function Navbar({ onMenuClick }: { onMenuClick: () => void }) {
  const { currentProfile, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [, setLocation] = useLocation();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/busca?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 w-full bg-background/80 backdrop-blur-md border-b border-border/50 transition-colors duration-300">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={onMenuClick}
            className="p-2 -ml-2 rounded-full hover:bg-accent text-muted-foreground hover:text-accent-foreground transition-colors md:hidden"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 bg-primary rounded-br-xl rounded-tl-xl flex items-center justify-center transform group-hover:scale-105 transition-transform">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4 22V2L22 12L4 22Z" fill="currentColor" />
              </svg>
            </div>
            <span className="text-xl font-bold tracking-tight hidden sm:block text-foreground">MovieFlix</span>
          </Link>
        </div>

        <div className="flex-1 max-w-xl mx-4">
          <form onSubmit={handleSearch} className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
            <input
              type="text"
              placeholder="Buscar filmes, séries..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-10 pr-4 rounded-full bg-accent border border-transparent focus:bg-background focus:border-primary/50 outline-none transition-all text-foreground placeholder:text-muted-foreground"
            />
          </form>
        </div>

        <div className="flex items-center gap-2">
          {currentProfile ? (
            <div className="relative" ref={dropdownRef}>
              <button 
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="outline-none"
              >
                <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-xl hover:ring-2 hover:ring-primary/50 transition-all cursor-pointer overflow-hidden border border-border">
                  {currentProfile.avatar}
                </div>
              </button>
              
              {dropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-popover border border-border rounded-md shadow-lg py-1 z-50 animate-in fade-in slide-in-from-top-2">
                  <div className="px-4 py-2 border-b border-border/50">
                    <p className="text-sm font-medium text-popover-foreground">{currentProfile.name}</p>
                  </div>
                  
                  <button 
                    onClick={() => { setDropdownOpen(false); setLocation('/perfil'); }} 
                    className="w-full text-left px-4 py-2 text-sm text-popover-foreground hover:bg-accent hover:text-accent-foreground flex items-center"
                  >
                    <UserCircle className="w-4 h-4 mr-2" /> Perfil
                  </button>
                  <button 
                    onClick={() => { setDropdownOpen(false); setLocation('/configuracoes'); }} 
                    className="w-full text-left px-4 py-2 text-sm text-popover-foreground hover:bg-accent hover:text-accent-foreground flex items-center"
                  >
                    <Settings className="w-4 h-4 mr-2" /> Configurações
                  </button>
                  <div className="border-t border-border/50 my-1"></div>
                  <button 
                    onClick={() => { setDropdownOpen(false); logout(); setLocation('/login'); }} 
                    className="w-full text-left px-4 py-2 text-sm text-destructive hover:bg-accent flex items-center"
                  >
                    <LogOut className="w-4 h-4 mr-2" /> Sair
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex gap-2">
              <Link href="/login" className="px-4 py-2 text-sm font-medium hover:text-primary transition-colors text-foreground">
                Entrar
              </Link>
              <Link href="/cadastro" className="px-4 py-2 text-sm font-medium bg-primary text-primary-foreground rounded-full hover:bg-primary/90 transition-colors">
                Cadastrar
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
