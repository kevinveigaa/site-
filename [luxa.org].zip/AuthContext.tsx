import React, { createContext, useContext, useEffect, useState } from 'react';
import type { User, Profile } from '../types';
import {
  loginUser,
  registerUser,
  persistUser,
  saveSession,
  clearSession,
  loadSession,
  saveCurrentProfile,
  createProfile,
  avatarOptions,
  hashPassword,
} from '../services/authService';
import {
  activateSubscription,
  cancelSubscription,
  type PlanoId,
} from '../services/subscriptionService';

export { hashPassword };

interface AuthContextType {
  user: User | null;
  currentProfile: Profile | null;
  login: (email: string, passwordHash: string) => Promise<boolean>;
  register: (name: string, email: string, passwordHash: string) => Promise<boolean>;
  logout: () => void;
  switchProfile: (profileId: string) => void;
  addProfile: (name: string, avatar: string) => void;
  updateProfile: (id: string, name: string, avatar: string) => void;
  deleteProfile: (id: string) => void;
  subscribe: (plano: PlanoId) => Promise<boolean>;
  cancelar: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [currentProfile, setCurrentProfile] = useState<Profile | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  // Carrega sessão salva ao inicializar
  useEffect(() => {
    const session = loadSession();
    if (session) {
      setUser(session.user);
      if (session.profileId) {
        const prof = session.user.profiles.find(p => p.id === session.profileId);
        if (prof) setCurrentProfile(prof);
      }
    }
    setIsLoaded(true);
  }, []);

  // ── Autenticação ────────────────────────────────────────────────────────────

  const login = async (email: string, passwordHash: string): Promise<boolean> => {
    const found = await loginUser(email, passwordHash);
    if (!found) return false;
    setUser(found);
    saveSession(found);
    return true;
  };

  const register = async (
    name: string,
    email: string,
    passwordHash: string
  ): Promise<boolean> => {
    const newUser = await registerUser(name, email, passwordHash);
    if (!newUser) return false;
    setUser(newUser);
    saveSession(newUser);
    return true;
  };

  const logout = () => {
    setUser(null);
    setCurrentProfile(null);
    clearSession();
  };

  // ── Perfis ──────────────────────────────────────────────────────────────────

  const switchProfile = (profileId: string) => {
    if (!user) return;
    const prof = user.profiles.find(p => p.id === profileId);
    if (prof) {
      setCurrentProfile(prof);
      saveCurrentProfile(prof.id);
    }
  };

  const addProfile = (name: string, avatar: string) => {
    if (!user || user.profiles.length >= 4) return;
    const newProfile = createProfile(name, avatar);
    const updatedUser = { ...user, profiles: [...user.profiles, newProfile] };
    setUser(updatedUser);
    persistUser(updatedUser);
  };

  const updateProfile = (id: string, name: string, avatar: string) => {
    if (!user) return;
    const updatedProfiles = user.profiles.map(p =>
      p.id === id ? { ...p, name, avatar } : p
    );
    const updatedUser = { ...user, profiles: updatedProfiles };
    setUser(updatedUser);
    persistUser(updatedUser);
    if (currentProfile?.id === id) {
      setCurrentProfile({ id, name, avatar });
    }
  };

  const deleteProfile = (id: string) => {
    if (!user || user.profiles.length <= 1) return;
    const updatedProfiles = user.profiles.filter(p => p.id !== id);
    const updatedUser = { ...user, profiles: updatedProfiles };
    setUser(updatedUser);
    persistUser(updatedUser);
    if (currentProfile?.id === id) {
      setCurrentProfile(null);
      clearSession();
      saveSession(updatedUser);
    }
  };

  // ── Assinatura ──────────────────────────────────────────────────────────────

  const subscribe = async (plano: PlanoId): Promise<boolean> => {
    if (!user) return false;
    try {
      const { user: updatedUser } = await activateSubscription(user, plano);
      setUser(updatedUser);
      persistUser(updatedUser);
      return true;
    } catch {
      return false;
    }
  };

  const cancelar = async (): Promise<void> => {
    if (!user) return;
    const updatedUser = await cancelSubscription(user);
    setUser(updatedUser);
    persistUser(updatedUser);
  };

  if (!isLoaded) return null;

  return (
    <AuthContext.Provider
      value={{
        user,
        currentProfile,
        login,
        register,
        logout,
        switchProfile,
        addProfile,
        updateProfile,
        deleteProfile,
        subscribe,
        cancelar,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
}
