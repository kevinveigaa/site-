import { Toaster } from 'sonner';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { MovieProvider } from '@/contexts/MovieContext';
import { Layout } from '@/components/layout/Layout';
import { MovieModal } from '@/components/movies/MovieModal';

import Home from '@/pages/Home';
import Filmes from '@/pages/Filmes';
import Series from '@/pages/Series';
import Animes from '@/pages/Animes';
import Documentarios from '@/pages/Documentarios';
import Infantil from '@/pages/Infantil';
import Busca from '@/pages/Busca';
import Favoritos from '@/pages/Favoritos';
import MinhaLista from '@/pages/MinhaLista';
import Historico from '@/pages/Historico';
import Continuar from '@/pages/Continuar';
import Perfil from '@/pages/Perfil';
import Configuracoes from '@/pages/Configuracoes';
import Login from '@/pages/Login';
import Cadastro from '@/pages/Cadastro';
import Assinatura from '@/pages/Assinatura';
import Admin from '@/pages/Admin';
import ProfileSelector from '@/components/auth/ProfileSelector';
import NotFound from '@/pages/not-found';

function MovieFlixApp() {
  const { currentProfile } = useAuth();

  return (
    <MovieProvider profileId={currentProfile?.id}>
      <Layout>
        <Switch>
          {/* ── Rotas públicas ──────────────────────────────────── */}
          <Route path="/login" component={Login} />
          <Route path="/cadastro" component={Cadastro} />
          <Route path="/assinatura" component={Assinatura} />

          {/* ── Seleção de perfil (requer login) ───────────────── */}
          <Route path="/selecionar-perfil" component={ProfileSelector} />

          {/* ── Painel administrativo ────────────────────────────── */}
          <Route path="/admin" component={Admin} />

          {/* ── Rotas principais (acessíveis sem login) ─────────── */}
          <Route path="/" component={Home} />
          <Route path="/filmes" component={Filmes} />
          <Route path="/series" component={Series} />
          <Route path="/animes" component={Animes} />
          <Route path="/documentarios" component={Documentarios} />
          <Route path="/infantil" component={Infantil} />
          <Route path="/busca" component={Busca} />

          {/* ── Rotas que requerem perfil selecionado ───────────── */}
          <Route path="/favoritos" component={Favoritos} />
          <Route path="/minha-lista" component={MinhaLista} />
          <Route path="/historico" component={Historico} />
          <Route path="/continuar" component={Continuar} />
          <Route path="/perfil" component={Perfil} />
          <Route path="/configuracoes" component={Configuracoes} />

          <Route component={NotFound} />
        </Switch>
        <MovieModal />
      </Layout>
      <Toaster theme="system" position="bottom-right" />
    </MovieProvider>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <MovieFlixApp />
        </WouterRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
