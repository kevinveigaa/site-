import React from 'react';
import { Link } from 'wouter';
import { Home } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center p-4 text-center">
      <h1 className="text-6xl md:text-8xl font-bold text-primary mb-4">404</h1>
      <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-6">Página não encontrada</h2>
      <p className="text-muted-foreground max-w-md mx-auto mb-8">
        Parece que você se perdeu no espaço. A página que você está procurando não existe ou foi movida.
      </p>
      <Link href="/" className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-bold rounded-full hover:bg-primary/90 transition-all hover:scale-105">
        <Home className="w-5 h-5" />
        Voltar ao Início
      </Link>
    </div>
  );
}
