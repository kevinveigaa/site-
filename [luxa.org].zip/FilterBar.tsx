import React from 'react';
import genresData from '@/data/genres.json';

export interface FilterState {
  genero: string;
  ano: string;
  qualidade: string;
  ordenar: string;
}

interface FilterBarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
}

export function FilterBar({ filters, setFilters }: FilterBarProps) {
  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 15 }, (_, i) => (currentYear - i).toString());

  return (
    <div className="flex flex-wrap items-center gap-3 py-4 border-b border-border/50 mb-6">
      <select 
        name="genero" 
        value={filters.genero} 
        onChange={handleChange}
        className="bg-card border border-border text-card-foreground text-sm rounded-lg px-3 py-2 outline-none focus:border-primary transition-colors"
      >
        <option value="">Todos os Gêneros</option>
        {genresData.map(g => (
          <option key={g.id} value={g.nome}>{g.nome}</option>
        ))}
      </select>

      <select 
        name="ano" 
        value={filters.ano} 
        onChange={handleChange}
        className="bg-card border border-border text-card-foreground text-sm rounded-lg px-3 py-2 outline-none focus:border-primary transition-colors"
      >
        <option value="">Todos os Anos</option>
        {years.map(y => (
          <option key={y} value={y}>{y}</option>
        ))}
      </select>

      <select 
        name="qualidade" 
        value={filters.qualidade} 
        onChange={handleChange}
        className="bg-card border border-border text-card-foreground text-sm rounded-lg px-3 py-2 outline-none focus:border-primary transition-colors"
      >
        <option value="">Qualquer Qualidade</option>
        <option value="HD">HD</option>
        <option value="FHD">FHD</option>
        <option value="4K">4K</option>
      </select>

      <div className="ml-auto flex items-center gap-2">
        <span className="text-sm text-muted-foreground hidden sm:inline">Ordenar por:</span>
        <select 
          name="ordenar" 
          value={filters.ordenar} 
          onChange={handleChange}
          className="bg-card border border-border text-card-foreground text-sm rounded-lg px-3 py-2 outline-none focus:border-primary transition-colors font-medium"
        >
          <option value="populares">Mais Populares</option>
          <option value="nota">Melhor Nota</option>
          <option value="recentes">Mais Recentes</option>
          <option value="vistos">Mais Vistos</option>
        </select>
      </div>
    </div>
  );
}
