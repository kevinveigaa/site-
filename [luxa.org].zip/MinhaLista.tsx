import React from 'react';
import { useMovies } from '@/contexts/MovieContext';
import { MovieGrid } from '@/components/movies/MovieGrid';
import { ListPlus } from 'lucide-react';

export default function MinhaLista() {
  const { movies, watchlist } = useMovies();
  
  const watchlistMovies = movies.filter(m => watchlist.includes(m.id));

  return (
    <div className="container mx-auto px-4 py-8 animate-in fade-in duration-300">
      <div className="mb-8 flex items-center gap-3">
        <ListPlus className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-1">Minha Lista</h1>
          <p className="text-muted-foreground">Títulos salvos para assistir mais tarde.</p>
        </div>
      </div>
      
      <MovieGrid 
        movies={watchlistMovies} 
        emptyMessage="Sua lista está vazia. Explore e adicione títulos para assistir depois!" 
      />
    </div>
  );
}
