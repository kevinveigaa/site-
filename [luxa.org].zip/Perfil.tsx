import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useMovies } from '@/contexts/MovieContext';
import { UserCircle, Save } from 'lucide-react';
import { toast } from 'sonner';

export default function Perfil() {
  const { user, currentProfile, updateProfile } = useAuth();
  const { favorites, watchlist, history } = useMovies();
  
  const [name, setName] = useState(currentProfile?.name || '');
  const [avatar, setAvatar] = useState(currentProfile?.avatar || '😎');

  if (!user || !currentProfile) return null;

  const handleSave = () => {
    if (!name.trim()) {
      toast.error('O nome não pode estar vazio');
      return;
    }
    updateProfile(currentProfile.id, name, avatar);
    toast.success('Perfil atualizado com sucesso!');
  };

  const avatars = ['😎', '👻', '👽', '🤖', '🦊', '🐯', '🐶', '🐱', '🐼', '🐨'];

  return (
    <div className="container mx-auto px-4 py-8 animate-in fade-in duration-300 max-w-4xl">
      <div className="mb-8 flex items-center gap-3">
        <UserCircle className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-1">Seu Perfil</h1>
          <p className="text-muted-foreground">Gerencie suas informações e avatar.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          {/* Edit Profile */}
          <div className="bg-card border border-border p-6 rounded-xl shadow-sm">
            <h2 className="text-xl font-bold mb-6">Editar Informações</h2>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Escolha seu Avatar</label>
                <div className="flex flex-wrap gap-3">
                  {avatars.map(emoji => (
                    <button
                      key={emoji}
                      onClick={() => setAvatar(emoji)}
                      className={`text-4xl w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                        avatar === emoji ? 'bg-primary/20 ring-2 ring-primary scale-110' : 'bg-secondary hover:bg-secondary/80'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Nome do Perfil</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-background border border-input rounded-lg px-4 py-3 outline-none focus:border-primary transition-colors text-foreground"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Email da Conta (Leitura)</label>
                <input
                  type="email"
                  value={user.email}
                  disabled
                  className="w-full bg-secondary border border-transparent rounded-lg px-4 py-3 text-muted-foreground cursor-not-allowed"
                />
              </div>

              <button
                onClick={handleSave}
                className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground font-bold py-3 rounded-lg hover:bg-primary/90 transition-colors"
              >
                <Save className="w-5 h-5" /> Salvar Alterações
              </button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="space-y-4">
          <div className="bg-card border border-border p-6 rounded-xl shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xl font-bold">
              {favorites.length}
            </div>
            <div>
              <p className="text-sm text-muted-foreground font-medium">Favoritos</p>
              <p className="text-xl font-bold text-foreground">Títulos Amados</p>
            </div>
          </div>

          <div className="bg-card border border-border p-6 rounded-xl shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center text-xl font-bold">
              {watchlist.length}
            </div>
            <div>
              <p className="text-sm text-muted-foreground font-medium">Minha Lista</p>
              <p className="text-xl font-bold text-foreground">Para Assistir</p>
            </div>
          </div>

          <div className="bg-card border border-border p-6 rounded-xl shadow-sm flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-green-500/10 text-green-500 flex items-center justify-center text-xl font-bold">
              {history.length}
            </div>
            <div>
              <p className="text-sm text-muted-foreground font-medium">Histórico</p>
              <p className="text-xl font-bold text-foreground">Títulos Vistos</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
