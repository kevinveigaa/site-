import React from 'react';
import { Play, Plus, Check, Heart, Star } from 'lucide-react';
import { useMovies } from '@/contexts/MovieContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import type { Movie } from '@/types';
import { cn } from '@/lib/utils';
import { useLocation } from 'wouter';

export function MovieCard({ movie, className }: { movie: Movie; className?: string }) {
  const { openModal, isFavorite, isInWatchlist, toggleFavorite, toggleWatchlist, getProgress } = useMovies();
  const { currentProfile } = useAuth();
  const [, setLocation] = useLocation();

  const favorite = isFavorite(movie.id);
  const inWatchlist = isInWatchlist(movie.id);
  const progress = getProgress(movie.id);

  const handlePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentProfile) {
      setLocation('/login');
      return;
    }
    // We open modal, then from modal user can play
    openModal(movie.id);
  };

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentProfile) {
      setLocation('/login');
      return;
    }
    toggleFavorite(movie.id);
    toast(favorite ? 'Removido dos Favoritos' : 'Adicionado aos Favoritos');
  };

  const handleWatchlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentProfile) {
      setLocation('/login');
      return;
    }
    toggleWatchlist(movie.id);
    toast(inWatchlist ? 'Removido da Minha Lista' : 'Adicionado à Minha Lista');
  };

  return (
    <div 
      className={cn("group relative w-full aspect-[2/3] rounded-lg overflow-hidden cursor-pointer bg-card transition-all duration-300 transform hover:scale-105 hover:z-10 shadow-lg hover:shadow-xl", className)}
      onClick={() => openModal(movie.id)}
    >
      <img 
        src={movie.poster} 
        alt={movie.titulo} 
        className="w-full h-full object-cover"
        loading="lazy"
      />
      
      {/* Qualidade Badge */}
      <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded text-[10px] font-bold text-white border border-white/20">
        {movie.qualidade}
      </div>
      
      {/* Progress bar if watched */}
      {progress > 0 && progress < 0.95 && (
        <div className="absolute bottom-0 left-0 w-full h-1 bg-gray-600">
          <div className="h-full bg-primary" style={{ width: `${progress * 100}%` }} />
        </div>
      )}

      {/* Hover Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
        <h3 className="text-white font-bold text-sm md:text-base leading-tight mb-1 line-clamp-2">
          {movie.titulo}
        </h3>
        
        <div className="flex items-center gap-2 text-xs text-gray-300 mb-3">
          <span>{movie.ano}</span>
          <span className="flex items-center gap-1 text-yellow-400">
            <Star className="w-3 h-3 fill-current" /> {movie.nota.toFixed(1)}
          </span>
          <span className="border border-gray-500 px-1 rounded text-[10px]">{movie.classificacaoIndicativa}</span>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={handlePlay}
            className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 transition-colors"
          >
            <Play className="w-4 h-4 ml-0.5 fill-current" />
          </button>
          
          <button 
            onClick={handleWatchlist}
            className="w-8 h-8 rounded-full border border-white/40 bg-black/40 text-white flex items-center justify-center hover:bg-white hover:text-black transition-colors"
          >
            {inWatchlist ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          </button>
          
          <button 
            onClick={handleFavorite}
            className="w-8 h-8 rounded-full border border-white/40 bg-black/40 text-white flex items-center justify-center hover:bg-white hover:text-black transition-colors ml-auto"
          >
            <Heart className={cn("w-4 h-4", favorite && "fill-primary text-primary border-transparent")} />
          </button>
        </div>
        
        <div className="flex flex-wrap gap-1 mt-3">
          {movie.genero.slice(0, 2).map(g => (
            <span key={g} className="text-[10px] px-1.5 py-0.5 rounded-full bg-white/20 text-white">
              {g}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
