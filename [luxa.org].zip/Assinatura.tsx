import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { PLANOS, type PlanoId } from '@/services/subscriptionService';
import { useLocation, Link } from 'wouter';
import { toast } from 'sonner';
import { Check, Crown, Zap, Star } from 'lucide-react';
import { cn } from '@/lib/utils';

const planoIcons = {
  basico: Zap,
  padrao: Star,
  premium: Crown,
};

export default function Assinatura() {
  const { user, currentProfile, subscribe } = useAuth();
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState<string | null>(null);

  const handleAssinar = async (planoId: PlanoId) => {
    if (!currentProfile) {
      setLocation('/login');
      return;
    }

    setLoading(planoId);
    try {
      const success = await subscribe(planoId);
      if (success) {
        toast.success(`Assinatura ${planoId} ativada com sucesso!`);
        setLocation('/');
      } else {
        toast.error('Erro ao ativar assinatura. Tente novamente.');
      }
    } catch {
      toast.error('Ocorreu um erro. Tente novamente.');
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Fundo decorativo — igual ao Login */}
      <div className="absolute inset-0 bg-primary/5 z-0" />
      <div className="absolute w-[70vw] h-[70vw] rounded-full bg-primary/8 blur-[150px] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-0 pointer-events-none" />

      <div className="relative z-10 container mx-auto px-4 py-16 animate-in fade-in duration-500">

        {/* Cabeçalho */}
        <div className="text-center mb-16">
          <div className="w-14 h-14 bg-primary rounded-br-2xl rounded-tl-2xl flex items-center justify-center mx-auto mb-6">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M4 22V2L22 12L4 22Z" fill="currentColor" />
            </svg>
          </div>

          {user?.assinaturaAtiva ? (
            <>
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
                Sua Assinatura
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Você já possui o plano <strong className="text-primary capitalize">{user.planoAssinatura}</strong> ativo.
                Aproveite todo o catálogo MovieFlix!
              </p>
              <Link
                href="/"
                className="inline-flex items-center gap-2 mt-8 px-8 py-3 bg-primary text-primary-foreground font-bold rounded-full hover:bg-primary/90 transition-all hover:scale-105"
              >
                Ir para o início
              </Link>
            </>
          ) : (
            <>
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
                Escolha seu Plano
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Acesso ilimitado a filmes, séries, animes e muito mais.
                Cancele quando quiser.
              </p>
            </>
          )}
        </div>

        {/* Planos */}
        {!user?.assinaturaAtiva && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {PLANOS.map((plano, idx) => {
              const Icon = planoIcons[plano.id as keyof typeof planoIcons];
              const isPopular = plano.id === 'padrao';
              const isLoading = loading === plano.id;

              return (
                <div
                  key={plano.id}
                  className={cn(
                    "relative flex flex-col bg-card/80 backdrop-blur-xl border rounded-2xl p-8 shadow-xl transition-all duration-300 hover:scale-[1.02]",
                    isPopular
                      ? "border-primary ring-2 ring-primary/30"
                      : "border-border"
                  )}
                >
                  {isPopular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <span className="bg-primary text-primary-foreground text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-widest">
                        Mais popular
                      </span>
                    </div>
                  )}

                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center mb-6",
                    isPopular ? "bg-primary" : "bg-secondary"
                  )}>
                    <Icon className={cn("w-6 h-6", isPopular ? "text-primary-foreground" : "text-foreground")} />
                  </div>

                  <h2 className="text-2xl font-bold text-foreground mb-1">{plano.nome}</h2>
                  <p className="text-muted-foreground text-sm mb-6">{plano.descricao}</p>

                  <div className="mb-8">
                    <span className="text-4xl font-bold text-foreground">
                      R$ {plano.preco.toFixed(2).replace('.', ',')}
                    </span>
                    <span className="text-muted-foreground text-sm">/mês</span>
                  </div>

                  <ul className="space-y-3 mb-8 flex-1">
                    {plano.recursos.map(recurso => (
                      <li key={recurso} className="flex items-center gap-3 text-sm">
                        <div className={cn(
                          "w-5 h-5 rounded-full flex items-center justify-center shrink-0",
                          isPopular ? "bg-primary/20 text-primary" : "bg-secondary text-foreground"
                        )}>
                          <Check className="w-3 h-3" />
                        </div>
                        <span className="text-foreground">{recurso}</span>
                      </li>
                    ))}
                  </ul>

                  <button
                    onClick={() => handleAssinar(plano.id as PlanoId)}
                    disabled={!!loading}
                    className={cn(
                      "w-full py-3 rounded-xl font-bold transition-all active:scale-[0.98] disabled:opacity-50",
                      isPopular
                        ? "bg-primary text-primary-foreground hover:bg-primary/90"
                        : "bg-secondary text-secondary-foreground hover:bg-secondary/80 border border-border"
                    )}
                  >
                    {isLoading ? 'Ativando...' : `Assinar ${plano.nome}`}
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {/* Rodapé */}
        <div className="text-center mt-12 text-muted-foreground text-sm">
          <p>Sem contratos de longa duração. Cancele quando quiser.</p>
          {!currentProfile && (
            <p className="mt-2">
              Precisa de uma conta?{' '}
              <Link href="/cadastro" className="text-primary hover:underline font-medium">
                Cadastre-se gratuitamente
              </Link>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
