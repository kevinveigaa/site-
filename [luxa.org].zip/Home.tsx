import React from 'react';
import { HeroBanner } from '@/components/movies/HeroBanner';
import { Carousel } from '@/components/movies/Carousel';
import { useMovies } from '@/contexts/MovieContext';

export default function Home() {
  const { movies } = useMovies();
  
  const emAlta = movies.filter(m => m.emAlta);
  const recomendados = movies.filter(m => m.recomendado);
  const filmes = movies.filter(m => m.tipo === 'filme').slice(0, 15);
  const series = movies.filter(m => m.tipo === 'serie').slice(0, 15);
  const animes = movies.filter(m => m.tipo === 'anime').slice(0, 12);
  const lancamentos = movies.filter(m => m.lancamento);
  const infantil = movies.filter(m => m.tipo === 'infantil');
  const docs = movies.filter(m => m.tipo === 'documentario');

  return (
    <div className="pb-20 animate-in fade-in duration-500">
      <HeroBanner />
      <div className="-mt-16 md:-mt-24 lg:-mt-32 relative z-30 space-y-4">
        <Carousel title="Em Alta" movies={emAlta} />
        <Carousel title="Lançamentos" movies={lancamentos} />
        <Carousel title="Recomendados para Você" movies={recomendados} />
        <Carousel title="Filmes de Sucesso" movies={filmes} />
        <Carousel title="Séries Imperdíveis" movies={series} />
        <Carousel title="Mundo Anime" movies={animes} />
        {infantil.length > 0 && <Carousel title="Para a Família" movies={infantil} />}
        {docs.length > 0 && <Carousel title="Documentários" movies={docs} />}
      </div>
    </div>
  );
}
