import React from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Home, Film, Tv, PlaySquare, Baby, 
  ListPlus, Heart, Clock, PlayCircle, 
  Settings, UserCircle, LogOut 
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function Sidebar({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [location] = useLocation();
  const { currentProfile, logout } = useAuth();

  const navItems = [
    { label: 'Início', icon: Home, path: '/' },
    { label: 'Filmes', icon: Film, path: '/filmes' },
    { label: 'Séries', icon: Tv, path: '/series' },
    { label: 'Animes', icon: PlaySquare, path: '/animes' },
    { label: 'Documentários', icon: PlayCircle, path: '/documentarios' },
    { label: 'Infantil', icon: Baby, path: '/infantil' },
  ];

  const listItems = [
    { label: 'Minha Lista', icon: ListPlus, path: '/minha-lista' },
    { label: 'Favoritos', icon: Heart, path: '/favoritos' },
    { label: 'Continuar', icon: PlayCircle, path: '/continuar' },
    { label: 'Histórico', icon: Clock, path: '/historico' },
  ];

  const userItems = [
    { label: 'Configurações', icon: Settings, path: '/configuracoes' },
    { label: 'Perfil', icon: UserCircle, path: '/perfil' },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-40 md:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed md:sticky top-0 md:top-16 h-screen md:h-[calc(100vh-4rem)] w-64 bg-card/50 backdrop-blur-xl border-r border-border/50 flex flex-col z-50 transition-transform duration-300 ease-in-out md:translate-x-0 overflow-y-auto overflow-x-hidden",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-4 md:hidden flex items-center gap-2 mb-4">
          <div className="w-8 h-8 bg-primary rounded-br-xl rounded-tl-xl flex items-center justify-center">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M4 22V2L22 12L4 22Z" fill="currentColor" />
            </svg>
          </div>
          <span className="text-xl font-bold tracking-tight">MovieFlix</span>
        </div>

        <nav className="flex-1 py-4 flex flex-col gap-1 px-3">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-3">Navegação</div>
          {navItems.map(item => (
            <Link key={item.path} href={item.path} className={cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
              location === item.path 
                ? "bg-primary/10 text-primary" 
                : "text-muted-foreground hover:bg-accent hover:text-foreground"
            )}>
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          ))}

          {currentProfile && (
            <>
              <div className="mt-6 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3">Sua Biblioteca</div>
              {listItems.map(item => (
                <Link key={item.path} href={item.path} className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  location === item.path 
                    ? "bg-primary/10 text-primary" 
                    : "text-muted-foreground hover:bg-accent hover:text-foreground"
                )}>
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Link>
              ))}

              <div className="mt-6 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3">Conta</div>
              {userItems.map(item => (
                <Link key={item.path} href={item.path} className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  location === item.path 
                    ? "bg-primary/10 text-primary" 
                    : "text-muted-foreground hover:bg-accent hover:text-foreground"
                )}>
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Link>
              ))}
              
              <button 
                onClick={() => logout()}
                className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors text-left mt-2"
              >
                <LogOut className="w-4 h-4" />
                Sair
              </button>
            </>
          )}
        </nav>
      </aside>
    </>
  );
}
