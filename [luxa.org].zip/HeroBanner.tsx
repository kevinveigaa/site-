import React, { useState, useEffect } from 'react';
import { Play, Plus, Check, Info } from 'lucide-react';
import { useMovies } from '@/contexts/MovieContext';
import { useAuth } from '@/contexts/AuthContext';
import { useLocation } from 'wouter';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export function HeroBanner() {
  const { movies, openModal, isInWatchlist, toggleWatchlist } = useMovies();
  const { currentProfile } = useAuth();
  const [, setLocation] = useLocation();
  const [currentIndex, setCurrentIndex] = useState(0);

  const destaques = movies.filter(m => m.destaque).slice(0, 5);

  useEffect(() => {
    if (destaques.length === 0) return;
    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % destaques.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [destaques.length]);

  if (destaques.length === 0) return null;

  const currentMovie = destaques[currentIndex];
  const inWatchlist = isInWatchlist(currentMovie.id);

  const handleWatchlist = () => {
    if (!currentProfile) {
      setLocation('/login');
      return;
    }
    toggleWatchlist(currentMovie.id);
    toast(inWatchlist ? 'Removido da Minha Lista' : 'Adicionado à Minha Lista');
  };

  const handlePlay = () => {
    if (!currentProfile) {
      setLocation('/login');
      return;
    }
    openModal(currentMovie.id);
  };

  return (
    <div className="relative w-full h-[70vh] md:h-[85vh] overflow-hidden bg-background">
      {destaques.map((movie, index) => (
        <div 
          key={movie.id}
          className={cn(
            "absolute inset-0 transition-opacity duration-1000",
            index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0"
          )}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/60 to-transparent z-10" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent z-10" />
          <img 
            src={movie.banner} 
            alt={movie.titulo} 
            className="w-full h-full object-cover object-top"
          />
        </div>
      ))}

      <div className="absolute inset-0 z-20 container mx-auto px-4 flex flex-col justify-center">
        <div className="max-w-2xl mt-16 md:mt-0">
          <div className="flex flex-wrap gap-2 mb-4">
            {currentMovie.genero.map(g => (
              <span key={g} className="text-xs font-semibold px-2 py-1 bg-primary/20 text-primary border border-primary/30 rounded-full">
                {g}
              </span>
            ))}
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-4 tracking-tight drop-shadow-lg">
            {currentMovie.titulo}
          </h1>
          
          <div className="flex items-center gap-4 text-sm md:text-base text-gray-300 mb-6 drop-shadow-md font-medium">
            <span className="text-green-400 font-bold">{currentMovie.nota.toFixed(1)} Pontos</span>
            <span>{currentMovie.ano}</span>
            <span className="border border-gray-400 px-1.5 py-0.5 rounded text-xs">{currentMovie.classificacaoIndicativa}</span>
            <span>{currentMovie.duracao} min</span>
            <span className="px-1.5 py-0.5 bg-white/20 rounded text-xs text-white">{currentMovie.qualidade}</span>
          </div>
          
          <p className="text-sm md:text-lg text-gray-200 mb-8 line-clamp-3 md:line-clamp-4 max-w-xl drop-shadow-md">
            {currentMovie.sinopse}
          </p>
          
          <div className="flex flex-wrap items-center gap-4">
            <button 
              onClick={handlePlay}
              className="flex items-center gap-2 px-6 md:px-8 py-3 bg-primary text-primary-foreground font-bold rounded-full hover:bg-primary/90 transition-all hover:scale-105 active:scale-95"
            >
              <Play className="w-5 h-5 fill-current" /> Assistir
            </button>
            
            <button 
              onClick={handleWatchlist}
              className="flex items-center gap-2 px-6 md:px-8 py-3 bg-black/50 text-white font-bold rounded-full border border-white/30 hover:bg-white hover:text-black transition-all hover:scale-105 active:scale-95 backdrop-blur-md"
            >
              {inWatchlist ? <Check className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
              Minha Lista
            </button>
            
            <button 
              onClick={() => openModal(currentMovie.id)}
              className="w-12 h-12 rounded-full bg-black/50 border border-white/30 flex items-center justify-center text-white hover:bg-white hover:text-black transition-all hover:scale-105 active:scale-95 backdrop-blur-md"
              title="Mais Informações"
            >
              <Info className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 right-8 z-30 flex gap-2">
        {destaques.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={cn(
              "w-3 h-3 rounded-full transition-all duration-300",
              index === currentIndex ? "bg-primary w-8" : "bg-white/50 hover:bg-white/80"
            )}
          />
        ))}
      </div>
    </div>
  );
}
