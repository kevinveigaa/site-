# MovieFlix — Guia Completo de Configuração

## Índice
1. [Estrutura do projeto](#estrutura)
2. [Como rodar localmente](#rodar-local)
3. [Como adicionar filmes / vídeos](#adicionar-filmes)
4. [Como conectar ao banco de dados (Supabase)](#banco-de-dados)
5. [Como fazer deploy no GitHub Pages / Vercel / Netlify](#deploy)
6. [Painel Admin](#admin)
7. [Personalização](#personalizacao)

---

## 1. Estrutura do Projeto <a name="estrutura"></a>

```
movieflix/
├── public/
│   ├── assistirfilme/          ← Coloque os arquivos .mp4 aqui
│   └── favicon.svg
├── src/
│   ├── components/
│   │   ├── auth/
│   │   │   ├── ProfileSelector.tsx   (tela de seleção de perfil)
│   │   │   └── ProtectedRoute.tsx    (proteção de rotas)
│   │   ├── layout/
│   │   │   ├── Layout.tsx            (estrutura com sidebar)
│   │   │   ├── Navbar.tsx            (barra superior)
│   │   │   └── Sidebar.tsx           (menu lateral)
│   │   ├── movies/
│   │   │   ├── Carousel.tsx          (carrossel de filmes)
│   │   │   ├── FilterBar.tsx         (filtros de busca)
│   │   │   ├── HeroBanner.tsx        (banner principal)
│   │   │   ├── MovieCard.tsx         (card de filme)
│   │   │   ├── MovieGrid.tsx         (grade de filmes)
│   │   │   ├── MovieModal.tsx        (modal com detalhes + botão assistir)
│   │   │   └── VideoPlayer.tsx       (player de vídeo)
│   │   └── ui/                       (componentes shadcn/ui)
│   ├── contexts/
│   │   ├── AuthContext.tsx           (autenticação e perfis)
│   │   ├── MovieContext.tsx          (favoritos, lista, histórico)
│   │   └── ThemeContext.tsx          (temas dark/light/etc)
│   ├── data/
│   │   ├── movies.json               ← Catálogo de filmes
│   │   ├── categories.json           ← Categorias
│   │   └── genres.json               ← Gêneros
│   ├── pages/
│   │   ├── Login.tsx
│   │   ├── Cadastro.tsx
│   │   ├── Assinatura.tsx            (planos de assinatura)
│   │   ├── Admin.tsx                 (painel administrativo)
│   │   ├── Home.tsx
│   │   ├── Filmes.tsx
│   │   ├── Series.tsx
│   │   ├── Animes.tsx
│   │   └── ...
│   ├── services/                     ← CAMADA DE DADOS (edite aqui para trocar de banco)
│   │   ├── db.ts                     (adapter — troque para Supabase aqui)
│   │   ├── authService.ts            (login, registro, sessão)
│   │   ├── subscriptionService.ts    (planos e assinaturas)
│   │   ├── playerService.ts          (normalização de título → arquivo de vídeo)
│   │   └── adminService.ts           (dados do painel admin)
│   ├── types/
│   │   └── index.ts                  (tipos TypeScript: Movie, User, etc)
│   ├── App.tsx                       (rotas principais)
│   └── index.css                     (tema visual completo)
├── package.json
├── vite.config.ts
├── tailwind.config.ts
└── tsconfig.json
```

---

## 2. Como Rodar Localmente <a name="rodar-local"></a>

### Pré-requisitos
- Node.js 18+ instalado
- pnpm instalado (`npm install -g pnpm`)

### Passos

```bash
# 1. Clone o repositório
git clone https://github.com/seu-usuario/movieflix.git
cd movieflix

# 2. Instale as dependências
pnpm install

# 3. Rode o servidor de desenvolvimento
pnpm dev
```

Acesse em: `http://localhost:5173`

---

## 3. Como Adicionar Filmes / Vídeos <a name="adicionar-filmes"></a>

### Adicionar ao catálogo (JSON)

Edite o arquivo `src/data/movies.json`. Cada filme tem esta estrutura:

```json
{
  "id": "filme-001",
  "titulo": "Nome do Filme",
  "tituloOriginal": "Movie Original Title",
  "tipo": "filme",
  "categoria": "Ação",
  "genero": ["Ação", "Aventura"],
  "tags": ["herois", "batalha"],
  "sinopse": "Descrição do filme...",
  "ano": 2024,
  "duracao": 120,
  "nota": 8.5,
  "popularidade": 95,
  "visualizacoes": 1000000,
  "classificacaoIndicativa": "14",
  "qualidade": "4K",
  "idiomas": ["Português", "Inglês"],
  "pais": "EUA",
  "diretor": "Nome do Diretor",
  "elenco": ["Ator 1", "Ator 2"],
  "poster": "https://url-da-imagem-poster.jpg",
  "banner": "https://url-da-imagem-banner.jpg",
  "trailer": "https://youtube.com/watch?v=...",
  "video": "https://url-fallback-video.mp4",
  "destaque": true,
  "emAlta": false,
  "lancamento": true,
  "recomendado": false
}
```

**Campos obrigatórios:** `id`, `titulo`, `tipo`, `poster`, `banner`, `sinopse`, `ano`

**Campo `tipo`:** `"filme"` | `"serie"` | `"anime"` | `"documentario"` | `"infantil"`

### Adicionar arquivo de vídeo

1. Normalize o título do filme usando esta regra:
   - Tudo em **minúsculas**
   - Remove **acentos** (ã → a, é → e, etc.)
   - Remove **espaços, hífens, pontos, dois-pontos** e outros especiais
   - Adiciona `.mp4` no final

2. Exemplos:
   | Título | Nome do arquivo |
   |--------|----------------|
   | `Vingadores: Ultimato` | `vingadoresultimato.mp4` |
   | `Homem-Aranha Novo` | `homemaranhanovo.mp4` |
   | `Avatar: O Caminho da Água` | `avatarocaminhodaagua.mp4` |
   | `Shrek 2` | `shrek2.mp4` |

3. Coloque o arquivo em: `public/assistirfilme/nome-normalizado.mp4`

> **Fallback:** Se o arquivo local não existir, o player tentará usar a URL do campo `"video"` do JSON. Se também falhar, exibe uma mensagem com o nome esperado do arquivo.

---

## 4. Como Conectar ao Banco de Dados (Supabase) <a name="banco-de-dados"></a>

O projeto foi construído com uma **camada de abstração** que torna a migração para Supabase (ou qualquer outro banco) simples e localizada em **um único arquivo**: `src/services/db.ts`.

### Passo a passo para migrar para Supabase

#### 4.1 Criar projeto no Supabase

1. Acesse [supabase.com](https://supabase.com) e crie uma conta
2. Crie um novo projeto
3. Anote a **URL** e a **chave anon** do projeto (em Settings → API)

#### 4.2 Criar as tabelas no Supabase

Execute este SQL no editor SQL do Supabase:

```sql
-- Tabela de usuários
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  profiles JSONB DEFAULT '[]'::jsonb,
  assinatura_ativa BOOLEAN DEFAULT false,
  plano_assinatura TEXT,
  criado_em TIMESTAMPTZ DEFAULT now()
);

-- Tabela de assinaturas
CREATE TABLE subscriptions (
  user_id UUID REFERENCES users(id) PRIMARY KEY,
  plano TEXT NOT NULL,
  ativa BOOLEAN DEFAULT true,
  data_inicio TIMESTAMPTZ DEFAULT now(),
  data_vencimento TIMESTAMPTZ
);

-- Tabela de pagamentos
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  valor NUMERIC(10,2) NOT NULL,
  plano TEXT NOT NULL,
  status TEXT DEFAULT 'pendente',
  metodo TEXT,
  criado_em TIMESTAMPTZ DEFAULT now()
);

-- Políticas de segurança (RLS)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Usuários só veem seus próprios dados
CREATE POLICY "users_own" ON users FOR ALL USING (auth.uid()::text = id::text);
CREATE POLICY "subs_own" ON subscriptions FOR ALL USING (auth.uid()::text = user_id::text);
CREATE POLICY "payments_own" ON payments FOR ALL USING (auth.uid()::text = user_id::text);
```

#### 4.3 Instalar o SDK do Supabase

```bash
pnpm add @supabase/supabase-js
```

#### 4.4 Criar arquivo de configuração

Crie o arquivo `src/lib/supabase.ts`:

```typescript
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
```

Crie o arquivo `.env` na raiz do projeto:

```env
VITE_SUPABASE_URL=https://seu-projeto.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-anon-aqui
```

> ⚠️ Adicione `.env` ao `.gitignore` para não vazar as chaves!

#### 4.5 Criar o SupabaseAdapter em `src/services/db.ts`

Adicione esta classe ao arquivo `db.ts` e troque a exportação:

```typescript
import { supabase } from '../lib/supabase';

class SupabaseAdapter implements DbAdapter {
  async getUserByEmail(email: string): Promise<User | null> {
    const { data } = await supabase
      .from('users')
      .select('*')
      .eq('email', email.toLowerCase())
      .single();
    if (!data) return null;
    return {
      id: data.id,
      name: data.name,
      email: data.email,
      passwordHash: data.password_hash,
      profiles: data.profiles,
      assinaturaAtiva: data.assinatura_ativa,
      planoAssinatura: data.plano_assinatura,
      criadoEm: data.criado_em,
    };
  }

  async getUserById(id: string): Promise<User | null> {
    const { data } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .single();
    if (!data) return null;
    return {
      id: data.id,
      name: data.name,
      email: data.email,
      passwordHash: data.password_hash,
      profiles: data.profiles,
      assinaturaAtiva: data.assinatura_ativa,
      planoAssinatura: data.plano_assinatura,
      criadoEm: data.criado_em,
    };
  }

  async getAllUsers(): Promise<User[]> {
    const { data } = await supabase.from('users').select('*');
    return (data || []).map(u => ({
      id: u.id,
      name: u.name,
      email: u.email,
      passwordHash: u.password_hash,
      profiles: u.profiles,
      assinaturaAtiva: u.assinatura_ativa,
      planoAssinatura: u.plano_assinatura,
      criadoEm: u.criado_em,
    }));
  }

  async createUser(user: User): Promise<User> {
    const { data } = await supabase
      .from('users')
      .insert({
        id: user.id,
        name: user.name,
        email: user.email,
        password_hash: user.passwordHash,
        profiles: user.profiles,
        assinatura_ativa: user.assinaturaAtiva,
        plano_assinatura: user.planoAssinatura,
        criado_em: user.criadoEm,
      })
      .select()
      .single();
    return user;
  }

  async updateUser(user: User): Promise<User> {
    await supabase
      .from('users')
      .update({
        name: user.name,
        profiles: user.profiles,
        assinatura_ativa: user.assinaturaAtiva,
        plano_assinatura: user.planoAssinatura,
      })
      .eq('id', user.id);
    return user;
  }

  async getSubscription(userId: string): Promise<Subscription | null> {
    const { data } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('user_id', userId)
      .single();
    if (!data) return null;
    return {
      userId: data.user_id,
      plano: data.plano,
      ativa: data.ativa,
      dataInicio: data.data_inicio,
      dataVencimento: data.data_vencimento,
    };
  }

  async upsertSubscription(subscription: Subscription): Promise<Subscription> {
    await supabase.from('subscriptions').upsert({
      user_id: subscription.userId,
      plano: subscription.plano,
      ativa: subscription.ativa,
      data_inicio: subscription.dataInicio,
      data_vencimento: subscription.dataVencimento,
    });
    return subscription;
  }

  async getPayments(userId?: string): Promise<Payment[]> {
    let query = supabase.from('payments').select('*');
    if (userId) query = query.eq('user_id', userId);
    const { data } = await query;
    return (data || []).map(p => ({
      id: p.id,
      userId: p.user_id,
      valor: p.valor,
      plano: p.plano,
      status: p.status,
      metodo: p.metodo,
      criadoEm: p.criado_em,
    }));
  }

  async addPayment(payment: Omit<Payment, 'id' | 'criadoEm'>): Promise<Payment> {
    const { data } = await supabase
      .from('payments')
      .insert({
        user_id: payment.userId,
        valor: payment.valor,
        plano: payment.plano,
        status: payment.status,
        metodo: payment.metodo,
      })
      .select()
      .single();
    return {
      id: data.id,
      userId: data.user_id,
      valor: data.valor,
      plano: data.plano,
      status: data.status,
      metodo: data.metodo,
      criadoEm: data.criado_em,
    };
  }
}

// ─── Troque esta linha para mudar de banco ───────────────────────────────────
// export const db: DbAdapter = new LocalStorageAdapter();   // ← atual
export const db: DbAdapter = new SupabaseAdapter();           // ← Supabase
```

---

## 5. Como Fazer Deploy <a name="deploy"></a>

### Vercel (recomendado — mais fácil)

1. Faça push do projeto para o GitHub
2. Acesse [vercel.com](https://vercel.com) → "New Project"
3. Importe o repositório
4. Em "Environment Variables", adicione:
   - `VITE_SUPABASE_URL` = sua URL do Supabase
   - `VITE_SUPABASE_ANON_KEY` = sua chave anon
5. Clique em Deploy

### Netlify

1. Faça push para o GitHub
2. Acesse [netlify.com](https://netlify.com) → "New site from Git"
3. Selecione o repositório
4. Build command: `pnpm build`
5. Publish directory: `dist`
6. Adicione as variáveis de ambiente (VITE_SUPABASE_*)

### GitHub Pages

> ⚠️ GitHub Pages não suporta rotas dinâmicas bem. Prefira Vercel ou Netlify.

Se quiser usar GitHub Pages mesmo assim:
1. Instale: `pnpm add -D gh-pages`
2. No `vite.config.ts`, adicione `base: '/nome-do-repo/'`
3. No `package.json`, adicione: `"deploy": "pnpm build && gh-pages -d dist"`
4. Rode: `pnpm deploy`

---

## 6. Painel Admin <a name="admin"></a>

### Como acessar

O painel admin está em `/admin`. Somente o usuário com email `admin@movieflix.com` tem acesso.

### Como criar a conta admin

1. Acesse `/cadastro` e crie uma conta com o email `admin@movieflix.com`
2. Pronto — ao acessar `/admin`, você terá acesso completo

### Para mudar o email do admin

Edite a constante em `src/pages/Admin.tsx`:
```typescript
const ADMIN_EMAIL = 'admin@movieflix.com'; // ← mude aqui
```

E em `src/components/auth/ProtectedRoute.tsx`:
```typescript
if (requireAdmin && user?.email !== 'admin@movieflix.com') { // ← e aqui
```

---

## 7. Personalização <a name="personalizacao"></a>

### Mudar nome e logo

Edite `src/components/layout/Navbar.tsx` — procure por "MovieFlix".

### Mudar preços dos planos

Edite `src/services/subscriptionService.ts` → array `PLANOS`.

### Adicionar novos temas

Edite `src/contexts/ThemeContext.tsx` e `src/index.css`.

### Mudar idioma do catálogo

Edite os campos `titulo`, `sinopse`, etc. no arquivo `src/data/movies.json`.

---

## Resumo Rápido

| Tarefa | Arquivo |
|--------|---------|
| Adicionar filmes ao catálogo | `src/data/movies.json` |
| Adicionar vídeos | `public/assistirfilme/*.mp4` |
| Conectar Supabase | `src/services/db.ts` + `.env` |
| Mudar preços dos planos | `src/services/subscriptionService.ts` |
| Mudar email do admin | `src/pages/Admin.tsx` |
| Mudar tema visual | `src/index.css` |
| Mudar logotipo/nome | `src/components/layout/Navbar.tsx` |
