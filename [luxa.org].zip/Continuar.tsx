import React from 'react';
import { useMovies } from '@/contexts/MovieContext';
import { MovieGrid } from '@/components/movies/MovieGrid';
import { PlayCircle } from 'lucide-react';

export default function Continuar() {
  const { movies, continueWatching } = useMovies();
  
  // Sort by recently updated
  const inProgress = continueWatching
    .filter(item => item.progress > 0 && item.progress < 0.95)
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .map(item => movies.find(m => m.id === item.movieId))
    .filter(m => m !== undefined) as typeof movies;

  return (
    <div className="container mx-auto px-4 py-8 animate-in fade-in duration-300">
      <div className="mb-8 flex items-center gap-3">
        <PlayCircle className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-1">Continuar Assistindo</h1>
          <p className="text-muted-foreground">Retome de onde parou.</p>
        </div>
      </div>
      
      <MovieGrid 
        movies={inProgress} 
        emptyMessage="Você não possui nenhum título em andamento no momento." 
      />
    </div>
  );
}
