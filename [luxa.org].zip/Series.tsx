import React, { useState, useMemo } from 'react';
import { useMovies } from '@/contexts/MovieContext';
import { MovieGrid } from '@/components/movies/MovieGrid';
import { FilterBar, FilterState } from '@/components/movies/FilterBar';

export default function Series() {
  const { movies } = useMovies();
  const [filters, setFilters] = useState<FilterState>({
    genero: '',
    ano: '',
    qualidade: '',
    ordenar: 'populares'
  });

  const filteredMovies = useMemo(() => {
    let result = movies.filter(m => m.tipo === 'serie');

    if (filters.genero) {
      result = result.filter(m => m.genero.includes(filters.genero));
    }
    if (filters.ano) {
      result = result.filter(m => m.ano.toString() === filters.ano);
    }
    if (filters.qualidade) {
      result = result.filter(m => m.qualidade === filters.qualidade);
    }

    result.sort((a, b) => {
      switch (filters.ordenar) {
        case 'nota': return b.nota - a.nota;
        case 'recentes': return b.ano - a.ano;
        case 'vistos': return b.visualizacoes - a.visualizacoes;
        case 'populares':
        default: return b.popularidade - a.popularidade;
      }
    });

    return result;
  }, [movies, filters]);

  return (
    <div className="container mx-auto px-4 py-8 animate-in fade-in duration-300">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">Séries</h1>
        <p className="text-muted-foreground">Maratone as melhores séries da atualidade.</p>
      </div>
      
      <FilterBar filters={filters} setFilters={setFilters} />
      
      <MovieGrid movies={filteredMovies} />
    </div>
  );
}
