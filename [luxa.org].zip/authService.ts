/**
 * Serviço de Autenticação — MovieFlix
 *
 * Toda lógica de autenticação centralizada aqui.
 * Usa db.ts como única fonte de acesso ao banco de dados.
 */

import { db } from './db';
import type { User, Profile } from '../types';

const DEFAULT_AVATARS = ['😎', '👻', '👽', '🤖', '🦊', '🐯', '🐶', '🐱', '🐼'];
const SESSION_KEY = 'mf_user';
const PROFILE_KEY = 'mf_current_profile';

// ─── Hash de senha ────────────────────────────────────────────────────────────

export async function hashPassword(password: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// ─── Login ────────────────────────────────────────────────────────────────────

export async function loginUser(
  email: string,
  passwordHash: string
): Promise<User | null> {
  const user = await db.getUserByEmail(email);
  if (!user || user.passwordHash !== passwordHash) return null;
  return user;
}

// ─── Registro ─────────────────────────────────────────────────────────────────

export async function registerUser(
  name: string,
  email: string,
  passwordHash: string
): Promise<User | null> {
  const existing = await db.getUserByEmail(email);
  if (existing) return null; // email já cadastrado

  const newUser: User = {
    id: crypto.randomUUID(),
    name,
    email,
    passwordHash,
    profiles: [
      {
        id: crypto.randomUUID(),
        name,
        avatar: DEFAULT_AVATARS[Math.floor(Math.random() * DEFAULT_AVATARS.length)],
      },
    ],
    assinaturaAtiva: false,
    planoAssinatura: undefined,
    criadoEm: new Date().toISOString(),
  };

  await db.createUser(newUser);
  return newUser;
}

// ─── Atualizar usuário no banco e sessão ──────────────────────────────────────

export async function persistUser(user: User): Promise<void> {
  await db.updateUser(user);
  saveSession(user);
}

// ─── Sessão local (mantém usuário logado) ─────────────────────────────────────

export function saveSession(user: User): void {
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
}

export function clearSession(): void {
  localStorage.removeItem(SESSION_KEY);
  localStorage.removeItem(PROFILE_KEY);
}

export function loadSession(): { user: User; profileId: string | null } | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const user = JSON.parse(raw) as User;
    const profileId = localStorage.getItem(PROFILE_KEY);
    return { user, profileId };
  } catch {
    return null;
  }
}

export function saveCurrentProfile(profileId: string): void {
  localStorage.setItem(PROFILE_KEY, profileId);
}

// ─── Operações de perfil ──────────────────────────────────────────────────────

export function createProfile(name: string, avatar: string): Profile {
  return { id: crypto.randomUUID(), name, avatar };
}

export const avatarOptions = ['😎', '👻', '👽', '🤖', '🦊', '🐯', '🐶', '🐱', '🐼', '🐨'];
