import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLocation } from 'wouter';

export default function ProfileSelector() {
  const { user, switchProfile } = useAuth();
  const [, setLocation] = useLocation();

  if (!user) {
    setLocation('/login');
    return null;
  }

  const handleSelect = (id: string) => {
    switchProfile(id);
    setLocation('/');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-background">
      <div className="text-center mb-12 animate-in fade-in slide-in-from-top-4 duration-700">
        <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Quem está assistindo?</h1>
        <p className="text-xl text-muted-foreground">Selecione seu perfil</p>
      </div>

      <div className="flex flex-wrap justify-center gap-8 md:gap-12 animate-in fade-in zoom-in-95 duration-700 delay-150">
        {user.profiles.map(p => (
          <button
            key={p.id}
            onClick={() => handleSelect(p.id)}
            className="group flex flex-col items-center gap-4 transition-transform hover:scale-110 focus:outline-none"
          >
            <div className="w-28 h-28 md:w-36 md:h-36 rounded-2xl bg-secondary flex items-center justify-center text-6xl shadow-xl group-hover:ring-4 group-hover:ring-primary transition-all overflow-hidden border border-border">
              {p.avatar}
            </div>
            <span className="text-xl font-medium text-muted-foreground group-hover:text-foreground transition-colors">
              {p.name}
            </span>
          </button>
        ))}
      </div>

      <div className="mt-16 animate-in fade-in duration-700 delay-300">
        <button 
          onClick={() => setLocation('/configuracoes')}
          className="px-6 py-2 border border-muted-foreground text-muted-foreground hover:border-foreground hover:text-foreground rounded-full font-medium transition-colors uppercase tracking-widest text-sm"
        >
          Gerenciar Perfis
        </button>
      </div>
    </div>
  );
}
