import React, { useState } from 'react';
import { Play, X, Plus, Check, Heart, Star } from 'lucide-react';
import { useMovies } from '@/contexts/MovieContext';
import { useAuth } from '@/contexts/AuthContext';
import { hasActiveSubscription } from '@/services/subscriptionService';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { VideoPlayer } from './VideoPlayer';
import { useLocation } from 'wouter';

export function MovieModal() {
  const { movies, selectedMovieId, closeModal, isFavorite, isInWatchlist, toggleFavorite, toggleWatchlist } = useMovies();
  const { currentProfile, user } = useAuth();
  const [, setLocation] = useLocation();
  const [isPlaying, setIsPlaying] = useState(false);

  if (!selectedMovieId) return null;
  const movie = movies.find(m => m.id === selectedMovieId);
  if (!movie) return null;

  const favorite = isFavorite(movie.id);
  const inWatchlist = isInWatchlist(movie.id);

  const handlePlay = () => {
    // 1. Verificar login
    if (!currentProfile) {
      closeModal();
      setLocation('/login');
      return;
    }

    // 2. Verificar assinatura ativa
    if (!hasActiveSubscription(user)) {
      closeModal();
      setLocation('/assinatura');
      return;
    }

    // 3. Abrir player
    setIsPlaying(true);
  };

  const handleWatchlist = () => {
    if (!currentProfile) {
      closeModal();
      setLocation('/login');
      return;
    }
    toggleWatchlist(movie.id);
    toast(inWatchlist ? 'Removido da Minha Lista' : 'Adicionado à Minha Lista');
  };

  const handleFavorite = () => {
    if (!currentProfile) {
      closeModal();
      setLocation('/login');
      return;
    }
    toggleFavorite(movie.id);
    toast(favorite ? 'Removido dos Favoritos' : 'Adicionado aos Favoritos');
  };

  if (isPlaying) {
    return <VideoPlayer movie={movie} onClose={() => setIsPlaying(false)} />;
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 md:p-12">
      <div
        className="absolute inset-0 bg-background/80 backdrop-blur-sm"
        onClick={closeModal}
      />

      <div className="relative w-full max-w-5xl max-h-[90vh] bg-card border border-border rounded-xl shadow-2xl overflow-hidden flex flex-col z-10 animate-in fade-in zoom-in-95 duration-200">

        {/* Banner header */}
        <div className="relative w-full h-64 sm:h-80 md:h-[400px] shrink-0">
          <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent z-10" />
          <img
            src={movie.banner}
            alt={movie.titulo}
            className="w-full h-full object-cover object-top"
          />
          <button
            onClick={closeModal}
            className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-black/50 text-white flex items-center justify-center hover:bg-white hover:text-black transition-colors border border-white/20"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-0 left-0 p-6 z-20 w-full flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-2 drop-shadow-md">{movie.titulo}</h2>
              <p className="text-sm text-gray-300 font-medium italic drop-shadow-md">{movie.tituloOriginal}</p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handlePlay}
                className="flex items-center gap-2 px-6 py-2.5 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-primary/90 transition-all hover:scale-105 shadow-lg"
              >
                <Play className="w-5 h-5 fill-current" /> Assistir
              </button>

              <button
                onClick={handleWatchlist}
                className="w-10 h-10 rounded-lg bg-black/50 border border-white/20 text-white flex items-center justify-center hover:bg-white hover:text-black transition-colors"
                title="Minha Lista"
              >
                {inWatchlist ? <Check className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
              </button>

              <button
                onClick={handleFavorite}
                className="w-10 h-10 rounded-lg bg-black/50 border border-white/20 text-white flex items-center justify-center hover:bg-white hover:text-black transition-colors"
                title="Favoritos"
              >
                <Heart className={cn("w-5 h-5", favorite && "fill-primary text-primary border-transparent")} />
              </button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-6">
              <div className="flex flex-wrap items-center gap-4 text-sm font-medium">
                <span className="text-green-500 font-bold flex items-center gap-1">
                  <Star className="w-4 h-4 fill-current" /> {movie.nota.toFixed(1)}
                </span>
                <span>{movie.ano}</span>
                <span className="border border-border px-1.5 py-0.5 rounded text-xs">{movie.classificacaoIndicativa}</span>
                <span>{movie.duracao} min</span>
                <span className="bg-primary/20 text-primary px-2 py-0.5 rounded text-xs">{movie.qualidade}</span>
              </div>

              <p className="text-base md:text-lg leading-relaxed text-muted-foreground">
                {movie.sinopse}
              </p>

              <div className="flex flex-wrap gap-2 pt-2">
                {movie.genero.map(g => (
                  <span key={g} className="px-3 py-1 bg-secondary rounded-full text-xs font-medium text-secondary-foreground">
                    {g}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-4 text-sm">
              <div>
                <span className="text-muted-foreground block mb-1">Elenco:</span>
                <span className="text-foreground">{movie.elenco.join(', ')}</span>
              </div>
              {movie.diretor && (
                <div>
                  <span className="text-muted-foreground block mb-1">Diretor:</span>
                  <span className="text-foreground">{movie.diretor}</span>
                </div>
              )}
              <div>
                <span className="text-muted-foreground block mb-1">País:</span>
                <span className="text-foreground">{movie.pais}</span>
              </div>
              <div>
                <span className="text-muted-foreground block mb-1">Áudio:</span>
                <span className="text-foreground">{movie.idiomas.join(', ')}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
