import React, { useMemo } from 'react';
import { useLocation } from 'wouter';
import { useMovies } from '@/contexts/MovieContext';
import { MovieGrid } from '@/components/movies/MovieGrid';
import { Search } from 'lucide-react';

export default function Busca() {
  const { movies } = useMovies();
  const searchParams = new URLSearchParams(window.location.search);
  const query = searchParams.get('q') || '';
  const lowerQuery = query.toLowerCase();

  const results = useMemo(() => {
    if (!lowerQuery) return [];
    return movies.filter(m => 
      m.titulo.toLowerCase().includes(lowerQuery) ||
      m.tituloOriginal.toLowerCase().includes(lowerQuery) ||
      m.sinopse.toLowerCase().includes(lowerQuery) ||
      m.elenco.some(a => a.toLowerCase().includes(lowerQuery)) ||
      m.tags.some(t => t.toLowerCase().includes(lowerQuery)) ||
      m.genero.some(g => g.toLowerCase().includes(lowerQuery))
    );
  }, [movies, lowerQuery]);

  return (
    <div className="container mx-auto px-4 py-8 animate-in fade-in duration-300">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
          <Search className="w-8 h-8 text-primary" /> Resultados da Busca
        </h1>
        {query ? (
          <p className="text-muted-foreground">
            Mostrando resultados para: <strong className="text-foreground">"{query}"</strong>
          </p>
        ) : (
          <p className="text-muted-foreground">Digite algo na barra de pesquisa para começar.</p>
        )}
      </div>

      {query && (
        <MovieGrid 
          movies={results} 
          emptyMessage={`Nenhum filme ou série encontrado para "${query}".`} 
        />
      )}
    </div>
  );
}
