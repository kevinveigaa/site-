import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { Settings, Palette, Users, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function Configuracoes() {
  const { theme, setTheme } = useTheme();
  const { user, addProfile, deleteProfile } = useAuth();
  const [newProfileName, setNewProfileName] = useState('');

  const themes = [
    { id: 'dark', name: 'Escuro', color: '#0a0a0f' },
    { id: 'light', name: 'Claro', color: '#f5f5f8' },
    { id: 'blue', name: 'Oceano', color: '#050b1f' },
    { id: 'red', name: 'Sangue', color: '#130507' },
    { id: 'purple', name: 'Místico', color: '#0c0617' },
    { id: 'pink', name: 'Rosa', color: '#130510' },
  ] as const;

  const handleAddProfile = () => {
    if (!newProfileName.trim()) {
      toast.error('O nome não pode estar vazio.');
      return;
    }
    if (user && user.profiles.length >= 4) {
      toast.error('Limite máximo de 4 perfis atingido.');
      return;
    }
    addProfile(newProfileName, '😎');
    setNewProfileName('');
    toast.success('Perfil criado com sucesso!');
  };

  if (!user) return null;

  return (
    <div className="container mx-auto px-4 py-8 animate-in fade-in duration-300 max-w-4xl">
      <div className="mb-8 flex items-center gap-3">
        <Settings className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-1">Configurações</h1>
          <p className="text-muted-foreground">Ajuste o app para o seu estilo.</p>
        </div>
      </div>

      <div className="space-y-8">
        {/* Theme Settings */}
        <section className="bg-card border border-border p-6 rounded-xl shadow-sm">
          <div className="flex items-center gap-2 mb-6">
            <Palette className="w-6 h-6 text-primary" />
            <h2 className="text-xl font-bold">Aparência</h2>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {themes.map(t => (
              <button
                key={t.id}
                onClick={() => setTheme(t.id)}
                className={`flex flex-col items-center gap-2 p-3 rounded-lg border-2 transition-all ${
                  theme === t.id ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50 bg-background'
                }`}
              >
                <div className="w-12 h-12 rounded-full border border-white/10 shadow-inner" style={{ backgroundColor: t.color }} />
                <span className="text-sm font-medium">{t.name}</span>
              </button>
            ))}
          </div>
        </section>

        {/* Profile Settings */}
        <section className="bg-card border border-border p-6 rounded-xl shadow-sm">
          <div className="flex items-center gap-2 mb-6">
            <Users className="w-6 h-6 text-primary" />
            <h2 className="text-xl font-bold">Gerenciar Perfis</h2>
          </div>
          
          <div className="grid gap-4 md:grid-cols-2">
            {user.profiles.map(p => (
              <div key={p.id} className="flex items-center justify-between p-4 bg-background border border-border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="text-3xl bg-secondary w-12 h-12 rounded-full flex items-center justify-center">
                    {p.avatar}
                  </div>
                  <span className="font-medium">{p.name}</span>
                </div>
                {user.profiles.length > 1 && (
                  <button 
                    onClick={() => {
                      deleteProfile(p.id);
                      toast('Perfil deletado.');
                    }}
                    className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-md transition-colors"
                    title="Excluir Perfil"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {user.profiles.length < 4 && (
            <div className="mt-6 flex gap-3">
              <input 
                type="text" 
                placeholder="Nome do novo perfil..."
                value={newProfileName}
                onChange={e => setNewProfileName(e.target.value)}
                className="flex-1 bg-background border border-input rounded-lg px-4 py-2 outline-none focus:border-primary"
              />
              <button 
                onClick={handleAddProfile}
                className="flex items-center gap-2 px-6 py-2 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-primary/90 transition-colors"
              >
                <Plus className="w-5 h-5" /> Adicionar
              </button>
            </div>
          )}
          <p className="mt-3 text-xs text-muted-foreground">Máximo de 4 perfis por conta.</p>
        </section>
      </div>
    </div>
  );
}
