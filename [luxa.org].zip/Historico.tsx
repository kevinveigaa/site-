import React from 'react';
import { useMovies } from '@/contexts/MovieContext';
import { Clock } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Historico() {
  const { movies, history } = useMovies();
  
  // Combine history with movie data
  const historyItems = history
    .map(h => ({
      ...h,
      movie: movies.find(m => m.id === h.movieId)
    }))
    .filter(h => h.movie)
    .sort((a, b) => b.watchedAt - a.watchedAt);

  return (
    <div className="container mx-auto px-4 py-8 animate-in fade-in duration-300">
      <div className="mb-8 flex items-center gap-3">
        <Clock className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-1">Histórico</h1>
          <p className="text-muted-foreground">Tudo o que você já assistiu na plataforma.</p>
        </div>
      </div>
      
      {historyItems.length === 0 ? (
        <div className="w-full py-20 flex flex-col items-center justify-center text-center">
          <p className="text-xl text-muted-foreground font-medium">Seu histórico está vazio.</p>
        </div>
      ) : (
        <div className="flex flex-col gap-4 max-w-4xl">
          {historyItems.map((item, i) => {
            const m = item.movie!;
            const date = new Date(item.watchedAt);
            return (
              <div key={`${item.movieId}-${i}`} className="flex gap-4 p-4 bg-card rounded-lg border border-border/50 shadow-sm hover:border-primary/50 transition-colors">
                <img src={m.poster} alt={m.titulo} className="w-20 sm:w-24 h-32 sm:h-36 object-cover rounded-md" />
                <div className="flex-1 flex flex-col justify-center">
                  <h3 className="text-lg sm:text-xl font-bold text-card-foreground mb-1">{m.titulo}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{m.sinopse}</p>
                  <div className="mt-auto flex flex-wrap items-center gap-4 text-xs font-medium text-muted-foreground">
                    <span className="bg-secondary px-2 py-1 rounded-full">{m.tipo.toUpperCase()}</span>
                    <span>{format(date, "d 'de' MMMM 'de' yyyy, HH:mm", { locale: ptBR })}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
