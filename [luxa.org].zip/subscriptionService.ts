/**
 * Serviço de Assinatura — MovieFlix
 *
 * Toda lógica de assinatura centralizada aqui.
 * Usa db.ts como única fonte de acesso ao banco de dados.
 *
 * Para integrar com Stripe, Mercado Pago, etc., adicione as
 * chamadas de API de pagamento aqui e atualize o adapter em db.ts.
 */

import { db } from './db';
import type { User, Subscription, Payment } from '../types';

// ─── Planos disponíveis ───────────────────────────────────────────────────────

export const PLANOS = [
  {
    id: 'basico',
    nome: 'Básico',
    preco: 19.90,
    descricao: 'Acesso a todo o catálogo em HD.',
    recursos: ['Catálogo completo', 'Qualidade HD', '1 tela simultânea'],
  },
  {
    id: 'padrao',
    nome: 'Padrão',
    preco: 29.90,
    descricao: 'Acesso total com Full HD e 2 telas.',
    recursos: ['Catálogo completo', 'Qualidade Full HD', '2 telas simultâneas', 'Downloads offline'],
  },
  {
    id: 'premium',
    nome: 'Premium',
    preco: 39.90,
    descricao: 'A melhor experiência em 4K Ultra HD.',
    recursos: ['Catálogo completo', 'Qualidade 4K Ultra HD', '4 telas simultâneas', 'Downloads offline', 'Sem anúncios'],
  },
] as const;

export type PlanoId = typeof PLANOS[number]['id'];

// ─── Verificar acesso ao conteúdo ─────────────────────────────────────────────

export function hasActiveSubscription(user: User | null): boolean {
  if (!user) return false;
  return user.assinaturaAtiva === true;
}

// ─── Ativar assinatura ────────────────────────────────────────────────────────
// Quando o pagamento for integrado, o backend confirmará o pagamento
// e chamará esta função após confirmação.

export async function activateSubscription(
  user: User,
  plano: PlanoId
): Promise<{ user: User; subscription: Subscription; payment: Payment }> {
  const agora = new Date();
  const vencimento = new Date(agora);
  vencimento.setMonth(vencimento.getMonth() + 1);

  const subscription: Subscription = {
    userId: user.id,
    plano,
    ativa: true,
    dataInicio: agora.toISOString(),
    dataVencimento: vencimento.toISOString(),
  };

  await db.upsertSubscription(subscription);

  const planoInfo = PLANOS.find(p => p.id === plano)!;
  const payment = await db.addPayment({
    userId: user.id,
    valor: planoInfo.preco,
    plano,
    status: 'aprovado',
    metodo: 'simulado',
  });

  // Atualizar flag no usuário
  const updatedUser: User = {
    ...user,
    assinaturaAtiva: true,
    planoAssinatura: plano,
  };

  return { user: updatedUser, subscription, payment };
}

// ─── Cancelar assinatura ──────────────────────────────────────────────────────

export async function cancelSubscription(user: User): Promise<User> {
  const sub = await db.getSubscription(user.id);
  if (sub) {
    await db.upsertSubscription({ ...sub, ativa: false });
  }

  return { ...user, assinaturaAtiva: false };
}

// ─── Buscar detalhes da assinatura ───────────────────────────────────────────

export async function getSubscriptionDetails(
  userId: string
): Promise<Subscription | null> {
  return db.getSubscription(userId);
}
