import React from 'react';
import { MovieCard } from './MovieCard';
import type { Movie } from '@/types';
import { cn } from '@/lib/utils';

interface MovieGridProps {
  movies: Movie[];
  className?: string;
  emptyMessage?: string;
}

export function MovieGrid({ movies, className, emptyMessage = "Nenhum filme encontrado." }: MovieGridProps) {
  if (movies.length === 0) {
    return (
      <div className="w-full py-20 flex flex-col items-center justify-center text-center px-4">
        <p className="text-xl text-muted-foreground font-medium">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className={cn("grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6", className)}>
      {movies.map((movie) => (
        <MovieCard key={movie.id} movie={movie} />
      ))}
    </div>
  );
}
