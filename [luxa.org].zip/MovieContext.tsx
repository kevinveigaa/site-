import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { Movie, HistoryItem, ContinueItem } from '../types';
import moviesData from '../data/movies.json';

interface MovieContextType {
  movies: Movie[];
  favorites: string[];
  watchlist: string[];
  history: HistoryItem[];
  continueWatching: ContinueItem[];
  selectedMovieId: string | null;
  toggleFavorite: (movieId: string) => void;
  toggleWatchlist: (movieId: string) => void;
  addToHistory: (movieId: string) => void;
  updateProgress: (movieId: string, progress: number) => void;
  removeFromContinue: (movieId: string) => void;
  isFavorite: (movieId: string) => boolean;
  isInWatchlist: (movieId: string) => boolean;
  getProgress: (movieId: string) => number;
  openModal: (movieId: string) => void;
  closeModal: () => void;
}

const MovieContext = createContext<MovieContextType | undefined>(undefined);

export function MovieProvider({ children, profileId }: { children: React.ReactNode; profileId: string | undefined }) {
  const [movies] = useState<Movie[]>(moviesData as Movie[]);
  
  const [favorites, setFavorites] = useState<string[]>([]);
  const [watchlist, setWatchlist] = useState<string[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [continueWatching, setContinueWatching] = useState<ContinueItem[]>([]);
  const [selectedMovieId, setSelectedMovieId] = useState<string | null>(null);

  // Load profile specific data
  useEffect(() => {
    if (!profileId) {
      setFavorites([]);
      setWatchlist([]);
      setHistory([]);
      setContinueWatching([]);
      return;
    }

    try {
      setFavorites(JSON.parse(localStorage.getItem(`mf_favorites_${profileId}`) || '[]'));
      setWatchlist(JSON.parse(localStorage.getItem(`mf_watchlist_${profileId}`) || '[]'));
      setHistory(JSON.parse(localStorage.getItem(`mf_history_${profileId}`) || '[]'));
      setContinueWatching(JSON.parse(localStorage.getItem(`mf_continue_${profileId}`) || '[]'));
    } catch (e) {
      console.error('Error loading movie data', e);
    }
  }, [profileId]);

  const toggleFavorite = useCallback((movieId: string) => {
    if (!profileId) return;
    setFavorites(prev => {
      const next = prev.includes(movieId) ? prev.filter(id => id !== movieId) : [...prev, movieId];
      localStorage.setItem(`mf_favorites_${profileId}`, JSON.stringify(next));
      return next;
    });
  }, [profileId]);

  const toggleWatchlist = useCallback((movieId: string) => {
    if (!profileId) return;
    setWatchlist(prev => {
      const next = prev.includes(movieId) ? prev.filter(id => id !== movieId) : [...prev, movieId];
      localStorage.setItem(`mf_watchlist_${profileId}`, JSON.stringify(next));
      return next;
    });
  }, [profileId]);

  const addToHistory = useCallback((movieId: string) => {
    if (!profileId) return;
    setHistory(prev => {
      const filtered = prev.filter(item => item.movieId !== movieId);
      const next = [{ movieId, watchedAt: Date.now() }, ...filtered];
      localStorage.setItem(`mf_history_${profileId}`, JSON.stringify(next));
      return next;
    });
  }, [profileId]);

  const updateProgress = useCallback((movieId: string, progress: number) => {
    if (!profileId) return;
    setContinueWatching(prev => {
      const filtered = prev.filter(item => item.movieId !== movieId);
      const next = [{ movieId, progress, updatedAt: Date.now() }, ...filtered].slice(0, 20);
      localStorage.setItem(`mf_continue_${profileId}`, JSON.stringify(next));
      return next;
    });
  }, [profileId]);

  const removeFromContinue = useCallback((movieId: string) => {
    if (!profileId) return;
    setContinueWatching(prev => {
      const next = prev.filter(item => item.movieId !== movieId);
      localStorage.setItem(`mf_continue_${profileId}`, JSON.stringify(next));
      return next;
    });
  }, [profileId]);

  const isFavorite = useCallback((movieId: string) => favorites.includes(movieId), [favorites]);
  const isInWatchlist = useCallback((movieId: string) => watchlist.includes(movieId), [watchlist]);
  const getProgress = useCallback((movieId: string) => {
    return continueWatching.find(item => item.movieId === movieId)?.progress || 0;
  }, [continueWatching]);

  const openModal = useCallback((movieId: string) => setSelectedMovieId(movieId), []);
  const closeModal = useCallback(() => setSelectedMovieId(null), []);

  return (
    <MovieContext.Provider value={{
      movies, favorites, watchlist, history, continueWatching, selectedMovieId,
      toggleFavorite, toggleWatchlist, addToHistory, updateProgress, removeFromContinue,
      isFavorite, isInWatchlist, getProgress, openModal, closeModal
    }}>
      {children}
    </MovieContext.Provider>
  );
}

export function useMovies() {
  const context = useContext(MovieContext);
  if (context === undefined) throw new Error('useMovies must be used within a MovieProvider');
  return context;
}
