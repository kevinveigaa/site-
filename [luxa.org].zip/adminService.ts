/**
 * Serviço Administrativo — MovieFlix
 *
 * Acesso privilegiado a dados para o painel de administração.
 * Toda consulta administrativa passa por este serviço.
 *
 * IMPORTANTE: O painel admin deve ser protegido no backend quando
 * o banco de dados for integrado. Atualmente usa db.ts localmente.
 */

import { db } from './db';
import type { User, Subscription, Payment } from '../types';
import moviesData from '../data/movies.json';

// ─── Usuários ─────────────────────────────────────────────────────────────────

export async function getAllUsers(): Promise<User[]> {
  return db.getAllUsers();
}

export async function getUserStats(): Promise<{
  total: number;
  comAssinatura: number;
  semAssinatura: number;
}> {
  const users = await db.getAllUsers();
  const comAssinatura = users.filter(u => u.assinaturaAtiva).length;
  return {
    total: users.length,
    comAssinatura,
    semAssinatura: users.length - comAssinatura,
  };
}

// ─── Assinaturas ──────────────────────────────────────────────────────────────

export async function getAllSubscriptions(): Promise<Subscription[]> {
  const users = await db.getAllUsers();
  const subs = await Promise.all(users.map(u => db.getSubscription(u.id)));
  return subs.filter((s): s is Subscription => s !== null);
}

export async function getSubscriptionStats(): Promise<{
  ativas: number;
  canceladas: number;
  basico: number;
  padrao: number;
  premium: number;
}> {
  const subs = await getAllSubscriptions();
  return {
    ativas: subs.filter(s => s.ativa).length,
    canceladas: subs.filter(s => !s.ativa).length,
    basico: subs.filter(s => s.plano === 'basico').length,
    padrao: subs.filter(s => s.plano === 'padrao').length,
    premium: subs.filter(s => s.plano === 'premium').length,
  };
}

// ─── Pagamentos ───────────────────────────────────────────────────────────────

export async function getAllPayments(): Promise<Payment[]> {
  return db.getPayments();
}

export async function getRevenueStats(): Promise<{
  total: number;
  aprovados: number;
  pendentes: number;
  cancelados: number;
}> {
  const payments = await db.getPayments();
  const aprovados = payments.filter(p => p.status === 'aprovado');
  return {
    total: aprovados.reduce((sum, p) => sum + p.valor, 0),
    aprovados: aprovados.length,
    pendentes: payments.filter(p => p.status === 'pendente').length,
    cancelados: payments.filter(p => p.status === 'cancelado').length,
  };
}

// ─── Filmes ───────────────────────────────────────────────────────────────────

export function getAllMovies() {
  return moviesData;
}

export function getMovieStats() {
  const movies = moviesData;
  return {
    total: movies.length,
    filmes: movies.filter(m => m.tipo === 'filme').length,
    series: movies.filter(m => m.tipo === 'serie').length,
    animes: movies.filter(m => m.tipo === 'anime').length,
    documentarios: movies.filter(m => m.tipo === 'documentario').length,
    infantil: movies.filter(m => m.tipo === 'infantil').length,
  };
}
