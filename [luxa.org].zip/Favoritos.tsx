import React from 'react';
import { useMovies } from '@/contexts/MovieContext';
import { MovieGrid } from '@/components/movies/MovieGrid';
import { Heart } from 'lucide-react';

export default function Favoritos() {
  const { movies, favorites } = useMovies();
  
  const favoriteMovies = movies.filter(m => favorites.includes(m.id));

  return (
    <div className="container mx-auto px-4 py-8 animate-in fade-in duration-300">
      <div className="mb-8 flex items-center gap-3">
        <Heart className="w-8 h-8 text-primary fill-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-1">Favoritos</h1>
          <p className="text-muted-foreground">Filmes e séries que você mais amou.</p>
        </div>
      </div>
      
      <MovieGrid 
        movies={favoriteMovies} 
        emptyMessage="Você ainda não adicionou nenhum título aos favoritos." 
      />
    </div>
  );
}
