import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLocation } from 'wouter';
import {
  getAllUsers,
  getAllSubscriptions,
  getAllPayments,
  getUserStats,
  getSubscriptionStats,
  getRevenueStats,
  getMovieStats,
  getAllMovies,
} from '@/services/adminService';
import type { User, Subscription, Payment } from '@/types';
import { cn } from '@/lib/utils';
import {
  Users,
  CreditCard,
  Film,
  BarChart3,
  Crown,
  ShieldCheck,
  AlertCircle,
  DollarSign,
  TrendingUp,
} from 'lucide-react';

type Tab = 'dashboard' | 'usuarios' | 'assinaturas' | 'pagamentos' | 'filmes';

const ADMIN_EMAIL = 'admin@movieflix.com';

export default function Admin() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');

  // Dados carregados
  const [users, setUsers] = useState<User[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [userStats, setUserStats] = useState({ total: 0, comAssinatura: 0, semAssinatura: 0 });
  const [subStats, setSubStats] = useState({ ativas: 0, canceladas: 0, basico: 0, padrao: 0, premium: 0 });
  const [revenueStats, setRevenueStats] = useState({ total: 0, aprovados: 0, pendentes: 0, cancelados: 0 });
  const [movieStats, setMovieStats] = useState({ total: 0, filmes: 0, series: 0, animes: 0, documentarios: 0, infantil: 0 });
  const movies = getAllMovies();

  // Proteger rota: apenas admin@movieflix.com
  useEffect(() => {
    if (!user) {
      setLocation('/login');
      return;
    }
    if (user.email !== ADMIN_EMAIL) {
      setLocation('/');
      return;
    }
  }, [user]);

  // Carregar dados
  useEffect(() => {
    async function loadData() {
      const [u, s, p, us, ss, rs] = await Promise.all([
        getAllUsers(),
        getAllSubscriptions(),
        getAllPayments(),
        getUserStats(),
        getSubscriptionStats(),
        getRevenueStats(),
      ]);
      setUsers(u);
      setSubscriptions(s);
      setPayments(p);
      setUserStats(us);
      setSubStats(ss);
      setRevenueStats(rs);
      setMovieStats(getMovieStats());
    }
    loadData();
  }, []);

  if (!user || user.email !== ADMIN_EMAIL) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center text-center p-8">
        <AlertCircle className="w-16 h-16 text-destructive mb-4" />
        <h1 className="text-2xl font-bold mb-2">Acesso Negado</h1>
        <p className="text-muted-foreground">Esta área é restrita a administradores.</p>
      </div>
    );
  }

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'usuarios', label: 'Usuários', icon: Users },
    { id: 'assinaturas', label: 'Assinaturas', icon: Crown },
    { id: 'pagamentos', label: 'Pagamentos', icon: CreditCard },
    { id: 'filmes', label: 'Filmes', icon: Film },
  ];

  return (
    <div className="container mx-auto px-4 py-8 animate-in fade-in duration-300 max-w-7xl">
      {/* Cabeçalho */}
      <div className="flex items-center gap-4 mb-8">
        <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
          <ShieldCheck className="w-6 h-6 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-3xl font-bold">Painel Administrativo</h1>
          <p className="text-muted-foreground">MovieFlix — Gestão completa da plataforma</p>
        </div>
      </div>

      {/* Tabs de navegação */}
      <div className="flex gap-1 mb-8 bg-secondary/50 p-1 rounded-xl overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap",
              activeTab === tab.id
                ? "bg-card text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* ── Dashboard ─────────────────────────────────────────────────────── */}
      {activeTab === 'dashboard' && (
        <div className="space-y-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard icon={Users} label="Total Usuários" value={userStats.total} color="blue" />
            <StatCard icon={Crown} label="Com Assinatura" value={subStats.ativas} color="primary" />
            <StatCard icon={DollarSign} label="Receita Total" value={`R$ ${revenueStats.total.toFixed(2)}`} color="green" />
            <StatCard icon={Film} label="Títulos" value={movieStats.total} color="purple" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                <Crown className="w-5 h-5 text-primary" /> Distribuição de Planos
              </h3>
              <div className="space-y-3">
                {[
                  { nome: 'Básico', count: subStats.basico, color: 'bg-blue-500' },
                  { nome: 'Padrão', count: subStats.padrao, color: 'bg-primary' },
                  { nome: 'Premium', count: subStats.premium, color: 'bg-yellow-500' },
                ].map(item => (
                  <div key={item.nome} className="flex items-center gap-3">
                    <div className={cn("w-3 h-3 rounded-full", item.color)} />
                    <span className="text-sm text-muted-foreground">{item.nome}</span>
                    <span className="ml-auto font-bold">{item.count}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                <Film className="w-5 h-5 text-primary" /> Catálogo por Tipo
              </h3>
              <div className="space-y-3">
                {[
                  { nome: 'Filmes', count: movieStats.filmes },
                  { nome: 'Séries', count: movieStats.series },
                  { nome: 'Animes', count: movieStats.animes },
                  { nome: 'Documentários', count: movieStats.documentarios },
                  { nome: 'Infantil', count: movieStats.infantil },
                ].map(item => (
                  <div key={item.nome} className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">{item.nome}</span>
                    <div className="flex-1 bg-secondary rounded-full h-2">
                      <div
                        className="bg-primary h-2 rounded-full"
                        style={{ width: `${Math.round((item.count / movieStats.total) * 100)}%` }}
                      />
                    </div>
                    <span className="font-bold text-sm w-8 text-right">{item.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Usuários ──────────────────────────────────────────────────────── */}
      {activeTab === 'usuarios' && (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4 mb-6">
            <StatCard icon={Users} label="Total" value={userStats.total} color="blue" />
            <StatCard icon={Crown} label="Com Assinatura" value={userStats.comAssinatura} color="primary" />
            <StatCard icon={AlertCircle} label="Sem Assinatura" value={userStats.semAssinatura} color="orange" />
          </div>

          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="p-4 border-b border-border">
              <h3 className="font-bold">Lista de Usuários ({users.length})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary/50">
                  <tr>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Nome</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Email</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Assinatura</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Plano</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Perfis</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Cadastro</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {users.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-8 text-muted-foreground">
                        Nenhum usuário cadastrado ainda.
                      </td>
                    </tr>
                  ) : (
                    users.map(u => (
                      <tr key={u.id} className="hover:bg-accent/30 transition-colors">
                        <td className="px-4 py-3 font-medium">{u.name}</td>
                        <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                        <td className="px-4 py-3">
                          <span className={cn(
                            "px-2 py-0.5 rounded-full text-xs font-bold",
                            u.assinaturaAtiva
                              ? "bg-green-500/20 text-green-400"
                              : "bg-red-500/20 text-red-400"
                          )}>
                            {u.assinaturaAtiva ? 'Ativa' : 'Inativa'}
                          </span>
                        </td>
                        <td className="px-4 py-3 capitalize text-muted-foreground">
                          {u.planoAssinatura || '—'}
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">{u.profiles.length}</td>
                        <td className="px-4 py-3 text-muted-foreground">
                          {u.criadoEm ? new Date(u.criadoEm).toLocaleDateString('pt-BR') : '—'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Assinaturas ───────────────────────────────────────────────────── */}
      {activeTab === 'assinaturas' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <StatCard icon={Crown} label="Ativas" value={subStats.ativas} color="primary" />
            <StatCard icon={AlertCircle} label="Canceladas" value={subStats.canceladas} color="orange" />
            <StatCard icon={TrendingUp} label="Plano Padrão" value={subStats.padrao} color="blue" />
            <StatCard icon={Crown} label="Plano Premium" value={subStats.premium} color="purple" />
          </div>

          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="p-4 border-b border-border">
              <h3 className="font-bold">Assinaturas ({subscriptions.length})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary/50">
                  <tr>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Usuário</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Plano</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Status</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Início</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Vencimento</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {subscriptions.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-8 text-muted-foreground">
                        Nenhuma assinatura registrada ainda.
                      </td>
                    </tr>
                  ) : (
                    subscriptions.map(s => (
                      <tr key={s.userId} className="hover:bg-accent/30 transition-colors">
                        <td className="px-4 py-3 text-muted-foreground font-mono text-xs">{s.userId.slice(0, 8)}...</td>
                        <td className="px-4 py-3 capitalize font-medium">{s.plano}</td>
                        <td className="px-4 py-3">
                          <span className={cn(
                            "px-2 py-0.5 rounded-full text-xs font-bold",
                            s.ativa ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"
                          )}>
                            {s.ativa ? 'Ativa' : 'Cancelada'}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">
                          {new Date(s.dataInicio).toLocaleDateString('pt-BR')}
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">
                          {s.dataVencimento ? new Date(s.dataVencimento).toLocaleDateString('pt-BR') : '—'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Pagamentos ────────────────────────────────────────────────────── */}
      {activeTab === 'pagamentos' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <StatCard icon={DollarSign} label="Receita Total" value={`R$ ${revenueStats.total.toFixed(2)}`} color="green" />
            <StatCard icon={Crown} label="Aprovados" value={revenueStats.aprovados} color="primary" />
            <StatCard icon={AlertCircle} label="Pendentes" value={revenueStats.pendentes} color="orange" />
            <StatCard icon={AlertCircle} label="Cancelados" value={revenueStats.cancelados} color="red" />
          </div>

          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="p-4 border-b border-border">
              <h3 className="font-bold">Histórico de Pagamentos ({payments.length})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary/50">
                  <tr>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">ID</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Plano</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Valor</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Status</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Método</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Data</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {payments.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-8 text-muted-foreground">
                        Nenhum pagamento registrado ainda.
                      </td>
                    </tr>
                  ) : (
                    payments.map(p => (
                      <tr key={p.id} className="hover:bg-accent/30 transition-colors">
                        <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{p.id.slice(0, 8)}...</td>
                        <td className="px-4 py-3 capitalize font-medium">{p.plano}</td>
                        <td className="px-4 py-3 font-bold text-green-400">
                          R$ {p.valor.toFixed(2).replace('.', ',')}
                        </td>
                        <td className="px-4 py-3">
                          <span className={cn(
                            "px-2 py-0.5 rounded-full text-xs font-bold",
                            p.status === 'aprovado' ? "bg-green-500/20 text-green-400"
                            : p.status === 'pendente' ? "bg-yellow-500/20 text-yellow-400"
                            : "bg-red-500/20 text-red-400"
                          )}>
                            {p.status.charAt(0).toUpperCase() + p.status.slice(1)}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground capitalize">{p.metodo || '—'}</td>
                        <td className="px-4 py-3 text-muted-foreground">
                          {new Date(p.criadoEm).toLocaleDateString('pt-BR')}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Filmes ────────────────────────────────────────────────────────── */}
      {activeTab === 'filmes' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
            <StatCard icon={Film} label="Total" value={movieStats.total} color="primary" />
            <StatCard icon={Film} label="Filmes" value={movieStats.filmes} color="blue" />
            <StatCard icon={Film} label="Séries" value={movieStats.series} color="purple" />
            <StatCard icon={Film} label="Animes" value={movieStats.animes} color="orange" />
            <StatCard icon={Film} label="Docs" value={movieStats.documentarios} color="green" />
            <StatCard icon={Film} label="Infantil" value={movieStats.infantil} color="pink" />
          </div>

          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="p-4 border-b border-border">
              <h3 className="font-bold">Catálogo de Títulos ({movies.length})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary/50">
                  <tr>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Título</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Tipo</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Gênero</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Ano</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Nota</th>
                    <th className="text-left px-4 py-3 text-muted-foreground font-medium">Qualidade</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {movies.slice(0, 50).map((m: any) => (
                    <tr key={m.id} className="hover:bg-accent/30 transition-colors">
                      <td className="px-4 py-3 font-medium max-w-xs truncate">{m.titulo}</td>
                      <td className="px-4 py-3 capitalize text-muted-foreground">{m.tipo}</td>
                      <td className="px-4 py-3 text-muted-foreground">{m.genero?.slice(0, 2).join(', ')}</td>
                      <td className="px-4 py-3 text-muted-foreground">{m.ano}</td>
                      <td className="px-4 py-3 text-yellow-400 font-bold">{m.nota?.toFixed(1)}</td>
                      <td className="px-4 py-3">
                        <span className="bg-primary/20 text-primary text-xs px-2 py-0.5 rounded font-bold">
                          {m.qualidade}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {movies.length > 50 && (
                <div className="p-4 text-center text-sm text-muted-foreground border-t border-border">
                  Exibindo 50 de {movies.length} títulos.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Componente auxiliar: Card de estatística ─────────────────────────────────

function StatCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ElementType;
  label: string;
  value: number | string;
  color: string;
}) {
  const colorMap: Record<string, string> = {
    primary: 'text-primary bg-primary/10',
    blue: 'text-blue-400 bg-blue-400/10',
    green: 'text-green-400 bg-green-400/10',
    purple: 'text-purple-400 bg-purple-400/10',
    orange: 'text-orange-400 bg-orange-400/10',
    red: 'text-red-400 bg-red-400/10',
    pink: 'text-pink-400 bg-pink-400/10',
  };

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center mb-3", colorMap[color] || colorMap.primary)}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="text-2xl font-bold text-foreground">{value}</div>
      <div className="text-xs text-muted-foreground mt-1">{label}</div>
    </div>
  );
}
