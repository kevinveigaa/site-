/**
 * Serviço do Player — MovieFlix
 *
 * Responsável por:
 * - Normalizar títulos para nomes de arquivos de vídeo
 * - Localizar o caminho correto do vídeo no servidor
 *
 * Vídeos devem estar em: public/assistirfilme/{titulo-normalizado}.mp4
 *
 * Exemplo:
 *   "Homem-Aranha Novo" → "homemaranhanovo.mp4"
 *   "Vingadores: Ultimato" → "vingadoresultimato.mp4"
 */

// ─── Normalização do título ───────────────────────────────────────────────────

/**
 * Converte um título de filme em nome de arquivo normalizado.
 * 1. Converte para minúsculas
 * 2. Remove acentos e diacríticos
 * 3. Remove caracteres especiais (pontuação, hífen, etc.)
 * 4. Remove espaços
 */
export function normalizeTitle(titulo: string): string {
  return titulo
    .toLowerCase()
    // Remove acentos via normalização Unicode
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    // Remove caracteres não-alfanuméricos (inclui espaços, hífens, pontos, etc.)
    .replace(/[^a-z0-9]/g, '');
}

// ─── Caminho do vídeo ─────────────────────────────────────────────────────────

/**
 * Retorna o caminho do vídeo local baseado no título do filme.
 * Os arquivos devem existir em public/assistirfilme/.
 *
 * @param titulo - Título do filme (ex: "Homem-Aranha Novo")
 * @returns Caminho do vídeo (ex: "/assistirfilme/homemaranhanovo.mp4")
 */
export function getLocalVideoPath(titulo: string): string {
  const filename = normalizeTitle(titulo);
  return `/assistirfilme/${filename}.mp4`;
}

/**
 * Retorna a URL do vídeo a ser reproduzido.
 * Prioriza o arquivo local; se não encontrar, usa a URL de fallback.
 *
 * @param titulo - Título do filme
 * @param fallbackUrl - URL de fallback (geralmente a URL do JSON de dados)
 * @returns URL do vídeo
 */
export function getVideoUrl(titulo: string, fallbackUrl?: string): string {
  // O player tentará a URL local primeiro e usará o fallback se não carregar
  return getLocalVideoPath(titulo);
}

/**
 * Verifica (via HEAD request) se o arquivo de vídeo local existe.
 * Útil para mostrar feedback ao usuário antes de tentar reproduzir.
 *
 * @param titulo - Título do filme
 * @returns true se o arquivo existe, false caso contrário
 */
export async function checkVideoExists(titulo: string): Promise<boolean> {
  const path = getLocalVideoPath(titulo);
  try {
    const response = await fetch(path, { method: 'HEAD' });
    return response.ok;
  } catch {
    return false;
  }
}
