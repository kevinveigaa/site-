import React, { useState } from 'react';
import { useAuth, hashPassword } from '@/contexts/AuthContext';
import { useLocation, Link } from 'wouter';
import { toast } from 'sonner';

export default function Cadastro() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { register } = useAuth();
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      toast.error('A senha deve ter no mínimo 8 caracteres.');
      return;
    }

    setIsLoading(true);
    try {
      const hash = await hashPassword(password);
      const success = await register(name, email, hash);
      if (success) {
        toast.success('Conta criada com sucesso!');
        setLocation('/selecionar-perfil');
      } else {
        toast.error('Este email já está em uso.');
      }
    } catch (err) {
      toast.error('Ocorreu um erro no cadastro.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-primary/5 z-0" />
      <div className="absolute w-[50vw] h-[50vw] rounded-full bg-primary/10 blur-[100px] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-0 pointer-events-none" />
      
      <div className="w-full max-w-md bg-card/80 backdrop-blur-xl border border-border p-8 rounded-2xl shadow-2xl relative z-10 animate-in fade-in slide-in-from-bottom-8 duration-500">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-primary rounded-br-2xl rounded-tl-2xl flex items-center justify-center mx-auto mb-4">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M4 22V2L22 12L4 22Z" fill="currentColor" />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-foreground">Cadastre-se</h1>
          <p className="text-muted-foreground mt-2">Crie sua conta para começar</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Nome Completo</label>
            <input
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full bg-background border border-input rounded-lg px-4 py-3 outline-none focus:border-primary transition-colors text-foreground"
              placeholder="Seu nome"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full bg-background border border-input rounded-lg px-4 py-3 outline-none focus:border-primary transition-colors text-foreground"
              placeholder="seu@email.com"
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Senha</label>
            <input
              type="password"
              required
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full bg-background border border-input rounded-lg px-4 py-3 outline-none focus:border-primary transition-colors text-foreground"
              placeholder="Mínimo 8 caracteres"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-primary text-primary-foreground font-bold py-3 rounded-lg hover:bg-primary/90 transition-all active:scale-[0.98] disabled:opacity-50 mt-2"
          >
            {isLoading ? 'Criando conta...' : 'Criar Conta'}
          </button>
        </form>

        <p className="text-center mt-6 text-muted-foreground">
          Já tem uma conta?{' '}
          <Link href="/login" className="text-primary hover:underline font-medium">
            Faça login
          </Link>
        </p>
      </div>
    </div>
  );
}
