/**
 * Camada de abstração do banco de dados — MovieFlix
 *
 * Toda comunicação com banco de dados deve passar por esta camada.
 * Para conectar ao Supabase (ou outro banco), basta substituir a
 * classe LocalStorageAdapter por um SupabaseAdapter mantendo a
 * mesma interface DbAdapter.
 *
 * NUNCA espalhe chamadas de banco pelo projeto — use apenas os
 * serviços em src/services/.
 */

import type { User, Subscription, Payment } from '../types';

// ─── Interface do adapter (contrato) ─────────────────────────────────────────

export interface DbAdapter {
  // Usuários
  getUserByEmail(email: string): Promise<User | null>;
  getUserById(id: string): Promise<User | null>;
  getAllUsers(): Promise<User[]>;
  createUser(user: User): Promise<User>;
  updateUser(user: User): Promise<User>;

  // Assinaturas
  getSubscription(userId: string): Promise<Subscription | null>;
  upsertSubscription(subscription: Subscription): Promise<Subscription>;

  // Pagamentos
  getPayments(userId?: string): Promise<Payment[]>;
  addPayment(payment: Omit<Payment, 'id' | 'criadoEm'>): Promise<Payment>;
}

// ─── Adapter de LocalStorage (implementação atual) ────────────────────────────
// Substitua esta classe por SupabaseAdapter quando o banco estiver pronto.

const KEYS = {
  users: 'mf_users',
  subscriptions: 'mf_subscriptions',
  payments: 'mf_payments',
} as const;

function readStorage<T>(key: string): T[] {
  try {
    return JSON.parse(localStorage.getItem(key) || '[]') as T[];
  } catch {
    return [];
  }
}

function writeStorage<T>(key: string, data: T[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

class LocalStorageAdapter implements DbAdapter {
  // ── Usuários ────────────────────────────────────────────────────────────────

  async getUserByEmail(email: string): Promise<User | null> {
    const users = readStorage<User>(KEYS.users);
    return users.find(u => u.email.toLowerCase() === email.toLowerCase()) ?? null;
  }

  async getUserById(id: string): Promise<User | null> {
    const users = readStorage<User>(KEYS.users);
    return users.find(u => u.id === id) ?? null;
  }

  async getAllUsers(): Promise<User[]> {
    return readStorage<User>(KEYS.users);
  }

  async createUser(user: User): Promise<User> {
    const users = readStorage<User>(KEYS.users);
    users.push(user);
    writeStorage(KEYS.users, users);
    return user;
  }

  async updateUser(updatedUser: User): Promise<User> {
    const users = readStorage<User>(KEYS.users);
    const idx = users.findIndex(u => u.id === updatedUser.id);
    if (idx !== -1) {
      users[idx] = updatedUser;
    } else {
      users.push(updatedUser);
    }
    writeStorage(KEYS.users, users);
    return updatedUser;
  }

  // ── Assinaturas ─────────────────────────────────────────────────────────────

  async getSubscription(userId: string): Promise<Subscription | null> {
    const subs = readStorage<Subscription>(KEYS.subscriptions);
    return subs.find(s => s.userId === userId) ?? null;
  }

  async upsertSubscription(subscription: Subscription): Promise<Subscription> {
    const subs = readStorage<Subscription>(KEYS.subscriptions);
    const idx = subs.findIndex(s => s.userId === subscription.userId);
    if (idx !== -1) {
      subs[idx] = subscription;
    } else {
      subs.push(subscription);
    }
    writeStorage(KEYS.subscriptions, subs);
    return subscription;
  }

  // ── Pagamentos ──────────────────────────────────────────────────────────────

  async getPayments(userId?: string): Promise<Payment[]> {
    const payments = readStorage<Payment>(KEYS.payments);
    if (userId) {
      return payments.filter(p => p.userId === userId);
    }
    return payments;
  }

  async addPayment(payment: Omit<Payment, 'id' | 'criadoEm'>): Promise<Payment> {
    const payments = readStorage<Payment>(KEYS.payments);
    const newPayment: Payment = {
      ...payment,
      id: crypto.randomUUID(),
      criadoEm: new Date().toISOString(),
    };
    payments.push(newPayment);
    writeStorage(KEYS.payments, payments);
    return newPayment;
  }
}

// ─── Instância global do adapter ──────────────────────────────────────────────
// Para trocar de adapter, substitua apenas esta linha:
//   export const db: DbAdapter = new SupabaseAdapter(supabaseClient);

export const db: DbAdapter = new LocalStorageAdapter();
