export interface Movie {
  id: string;
  titulo: string;
  tituloOriginal: string;
  tipo: 'filme' | 'serie' | 'anime' | 'documentario' | 'infantil';
  categoria: string;
  genero: string[];
  tags: string[];
  sinopse: string;
  ano: number;
  duracao: number;
  nota: number;
  popularidade: number;
  visualizacoes: number;
  classificacaoIndicativa: string;
  qualidade: string;
  idiomas: string[];
  pais: string;
  diretor?: string;
  elenco: string[];
  atores?: string;
  poster: string;
  banner: string;
  trailer: string;
  video: string;
  destaque: boolean;
  emAlta: boolean;
  lancamento: boolean;
  recomendado: boolean;
}

export interface Profile {
  id: string;
  name: string;
  avatar: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  profiles: Profile[];
  /** Controla acesso ao conteúdo. Será migrado para banco de dados futuramente. */
  assinaturaAtiva: boolean;
  /** Plano da assinatura: 'basico' | 'padrao' | 'premium' */
  planoAssinatura?: string;
  /** Data de criação da conta (ISO string) */
  criadoEm: string;
}

export interface HistoryItem {
  movieId: string;
  watchedAt: number;
}

export interface ContinueItem {
  movieId: string;
  progress: number;
  updatedAt: number;
}

export interface Subscription {
  userId: string;
  plano: string;
  ativa: boolean;
  dataInicio: string;
  dataVencimento: string | null;
}

export interface Payment {
  id: string;
  userId: string;
  valor: number;
  plano: string;
  status: 'pendente' | 'aprovado' | 'cancelado';
  criadoEm: string;
  metodo?: string;
}
