import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, Minimize, X, SkipBack, SkipForward, AlertCircle } from 'lucide-react';
import type { Movie } from '@/types';
import { useMovies } from '@/contexts/MovieContext';
import { getLocalVideoPath } from '@/services/playerService';

export function VideoPlayer({ movie, onClose }: { movie: Movie; onClose: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const { updateProgress, addToHistory, getProgress } = useMovies();

  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [videoError, setVideoError] = useState(false);
  const [usingFallback, setUsingFallback] = useState(false);

  const controlsTimeoutRef = useRef<NodeJS.Timeout>();

  // Resolve o caminho do vídeo: tenta local primeiro, usa fallback se falhar
  const localVideoPath = getLocalVideoPath(movie.titulo);
  const fallbackVideoUrl = movie.video;

  useEffect(() => {
    const savedProgress = getProgress(movie.id);
    if (videoRef.current && savedProgress > 0) {
      const onLoadedMetadata = () => {
        if (videoRef.current) {
          videoRef.current.currentTime = videoRef.current.duration * savedProgress;
        }
      };
      videoRef.current.addEventListener('loadedmetadata', onLoadedMetadata);
      return () => videoRef.current?.removeEventListener('loadedmetadata', onLoadedMetadata);
    }
  }, [movie.id, getProgress]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) videoRef.current.pause();
      else videoRef.current.play();
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const p = videoRef.current.currentTime / videoRef.current.duration;
      const ct = videoRef.current.currentTime;
      setProgress(p || 0);
      setCurrentTime(ct);

      if (Math.floor(p * 100) % 5 === 0) {
        updateProgress(movie.id, p);
      }
      if (p > 0.95) {
        addToHistory(movie.id);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const p = parseFloat(e.target.value);
    setProgress(p);
    if (videoRef.current) {
      videoRef.current.currentTime = p * videoRef.current.duration;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = parseFloat(e.target.value);
    setVolume(v);
    if (videoRef.current) {
      videoRef.current.volume = v;
      setIsMuted(v === 0);
    }
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  // Fallback: se o vídeo local não carregar, tenta a URL do JSON de dados
  const handleVideoError = () => {
    if (!usingFallback && fallbackVideoUrl && fallbackVideoUrl !== localVideoPath) {
      setUsingFallback(true);
      setVideoError(false);
      if (videoRef.current) {
        videoRef.current.src = fallbackVideoUrl;
        videoRef.current.load();
      }
    } else {
      setVideoError(true);
    }
  };

  // Atalhos de teclado
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.code === 'ArrowRight') {
        if (videoRef.current) videoRef.current.currentTime += 10;
      } else if (e.code === 'ArrowLeft') {
        if (videoRef.current) videoRef.current.currentTime -= 10;
      } else if (e.code === 'KeyF') {
        toggleFullscreen();
      } else if (e.code === 'KeyM') {
        toggleMute();
      } else if (e.code === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isMuted, onClose]);

  const formatTime = (time: number) => {
    if (isNaN(time) || !isFinite(time)) return '00:00';
    const m = Math.floor(time / 60);
    const s = Math.floor(time % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[200] bg-black flex items-center justify-center"
      onMouseMove={handleMouseMove}
    >
      {videoError ? (
        // Estado de erro: vídeo não encontrado nem no local nem no fallback
        <div className="flex flex-col items-center justify-center gap-6 text-white text-center p-8">
          <AlertCircle className="w-16 h-16 text-primary" />
          <div>
            <h2 className="text-2xl font-bold mb-2">Vídeo não disponível</h2>
            <p className="text-gray-400 max-w-md">
              O arquivo de vídeo para <strong>{movie.titulo}</strong> não foi encontrado.
            </p>
            <p className="text-gray-500 text-sm mt-2">
              Adicione o arquivo em: <code className="bg-white/10 px-2 py-0.5 rounded">public/assistirfilme/{getLocalVideoPath(movie.titulo).split('/').pop()}</code>
            </p>
          </div>
          <button
            onClick={onClose}
            className="px-6 py-3 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-primary/90 transition-colors"
          >
            Voltar
          </button>
        </div>
      ) : (
        <>
          <video
            ref={videoRef}
            src={localVideoPath}
            className="w-full h-full object-contain"
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onError={handleVideoError}
            onClick={togglePlay}
          />

          {/* Overlay de controles */}
          <div
            className={`absolute inset-0 flex flex-col justify-between p-4 md:p-6 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
          >
            {/* Barra superior */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={onClose}
                  className="w-10 h-10 rounded-full bg-black/50 text-white flex items-center justify-center hover:bg-white hover:text-black transition-colors border border-white/20"
                >
                  <X className="w-5 h-5" />
                </button>
                <div>
                  <h3 className="text-white font-bold text-lg drop-shadow-lg">{movie.titulo}</h3>
                  {usingFallback && (
                    <span className="text-xs text-yellow-400">Usando fonte alternativa</span>
                  )}
                </div>
              </div>
            </div>

            {/* Barra de progresso e controles inferiores */}
            <div className="space-y-3 bg-gradient-to-t from-black/80 to-transparent pt-12 -mx-4 md:-mx-6 px-4 md:px-6 pb-0">
              {/* Barra de progresso */}
              <div className="flex items-center gap-3 text-white text-sm">
                <span className="w-12 text-right shrink-0">{formatTime(currentTime)}</span>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.001"
                  value={progress}
                  onChange={handleSeek}
                  className="flex-1 h-1 bg-white/30 rounded-full appearance-none accent-primary cursor-pointer"
                />
                <span className="w-12 shrink-0">{formatTime(duration)}</span>
              </div>

              {/* Controles */}
              <div className="flex items-center justify-between pb-2">
                <div className="flex items-center gap-4 md:gap-6">
                  <button onClick={togglePlay} className="text-white hover:text-primary transition-colors">
                    {isPlaying
                      ? <Pause className="w-8 h-8 fill-current" />
                      : <Play className="w-8 h-8 fill-current" />}
                  </button>

                  <button
                    onClick={() => { if (videoRef.current) videoRef.current.currentTime -= 10; }}
                    className="text-white hover:text-white/70"
                  >
                    <SkipBack className="w-6 h-6" />
                  </button>
                  <button
                    onClick={() => { if (videoRef.current) videoRef.current.currentTime += 10; }}
                    className="text-white hover:text-white/70"
                  >
                    <SkipForward className="w-6 h-6" />
                  </button>

                  <div className="flex items-center gap-2 group">
                    <button onClick={toggleMute} className="text-white hover:text-white/70">
                      {isMuted || volume === 0
                        ? <VolumeX className="w-6 h-6" />
                        : <Volume2 className="w-6 h-6" />}
                    </button>
                    <div className="w-0 overflow-hidden group-hover:w-24 transition-all duration-300">
                      <input
                        type="range"
                        min="0" max="1" step="0.05"
                        value={isMuted ? 0 : volume}
                        onChange={handleVolumeChange}
                        className="w-full h-1 bg-gray-600 rounded-full appearance-none accent-primary"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <select
                    className="bg-transparent text-white font-medium outline-none cursor-pointer text-sm"
                    onChange={(e) => {
                      if (videoRef.current) videoRef.current.playbackRate = parseFloat(e.target.value);
                    }}
                    defaultValue="1"
                  >
                    <option value="0.5" className="text-black">0.5x</option>
                    <option value="1" className="text-black">1x</option>
                    <option value="1.5" className="text-black">1.5x</option>
                    <option value="2" className="text-black">2x</option>
                  </select>

                  <button onClick={toggleFullscreen} className="text-white hover:text-white/70">
                    {isFullscreen ? <Minimize className="w-6 h-6" /> : <Maximize className="w-6 h-6" />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
